-- This SQL file is for manually creating the discord_users table in Supabase
-- Execute this in the Supabase SQL Editor if the automatic creation script fails

-- Create extension for UUID generation if not exists
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create discord_users table
CREATE TABLE IF NOT EXISTS discord_users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    discord_id TEXT NOT NULL UNIQUE,
    username TEXT,
    premium BOOLEAN DEFAULT FALSE,
    premium_tier INTEGER DEFAULT 0,
    preferences JSONB DEFAULT '{"preferred_language": "en", "preferred_model": "gpt-3.5-turbo-0125"}',
    opt_in_features JSONB DEFAULT '{"notifications": false, "beta_features": false}',
    tebex_customer_id TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create RLS policies for the table
-- By default, we'll restrict all access and then allow specific operations

-- First, enable RLS on the table
ALTER TABLE discord_users ENABLE ROW LEVEL SECURITY;

-- Then create policies for each operation
-- Allow insert for authenticated users
CREATE POLICY "Allow users to insert their own data" 
ON discord_users FOR INSERT 
TO authenticated 
WITH CHECK (auth.uid()::text = discord_id OR auth.role() = 'service_role');

-- Allow select for authenticated users on their own data
CREATE POLICY "Allow users to view their own data" 
ON discord_users FOR SELECT 
TO authenticated 
USING (auth.uid()::text = discord_id OR auth.role() = 'service_role');

-- Allow update for authenticated users on their own data
CREATE POLICY "Allow users to update their own data" 
ON discord_users FOR UPDATE 
TO authenticated 
USING (auth.uid()::text = discord_id OR auth.role() = 'service_role');

-- Create trigger for updated_at
CREATE OR REPLACE FUNCTION update_modified_column() 
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW; 
END;
$$ language 'plpgsql';

CREATE TRIGGER update_discord_users_updated_at
BEFORE UPDATE ON discord_users
FOR EACH ROW
EXECUTE PROCEDURE update_modified_column();