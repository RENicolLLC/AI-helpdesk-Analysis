# Supabase Setup for AIkitsBot

This guide will help you set up your Supabase database for AIkitsBot premium features.

## Prerequisites

1. You have already created a Supabase project at https://supabase.com
2. You have your Supabase URL and keys (anon key and service role key)
3. You've added these keys to your .env file:
   ```
   SUPABASE_URL=https://your-project-id.supabase.co
   SUPABASE_KEY=your-anon-key
   SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
   ```

## Setting Up the Tables

### Method 1: Using the Supabase SQL Editor (Recommended)

1. Log in to your Supabase dashboard
2. Go to the SQL Editor in the left sidebar
3. Create a new query
4. Copy the contents of `discord_users.sql` into the editor
5. Click "Run" to create the discord_users table
6. Repeat steps 3-5 for `token_usage.sql`

### Method 2: Using the Table Editor

If you prefer the visual editor:

1. Go to the Table Editor in the left sidebar
2. Click "New Table"
3. Create a table with the following structure:

#### discord_users table
- `id` (uuid, primary key, default: uuid_generate_v4())
- `discord_id` (text, not null, unique)
- `username` (text)
- `premium` (boolean, default: false)
- `premium_tier` (integer, default: 0)
- `preferences` (jsonb, default: '{"preferred_language": "en", "preferred_model": "gpt-3.5-turbo-0125"}')
- `opt_in_features` (jsonb, default: '{"notifications": false, "beta_features": false}')
- `tebex_customer_id` (text)
- `created_at` (timestamptz, default: now())
- `updated_at` (timestamptz, default: now())

#### token_usage table
- `id` (uuid, primary key, default: uuid_generate_v4())
- `discord_id` (text, not null)
- `command` (text)
- `model` (text)
- `tokens` (integer)
- `estimated_cost` (float)
- `timestamp` (timestamptz, default: now())

## Verifying the Setup

After creating the tables, you can run the `setup_supabase.py` script to verify the connection and insert a test record:

```bash
python setup_supabase.py
```

If successful, you should see a message confirming the tables exist and a test record was inserted.

## Troubleshooting

1. If you see "Not authorized" errors, check your API keys in the .env file
2. If the tables don't appear, make sure you're in the "public" schema
3. If you see "relation does not exist" errors, make sure the tables were created successfully

For more help, check the Supabase documentation at https://supabase.com/docs