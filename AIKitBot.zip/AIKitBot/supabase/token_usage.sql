-- This SQL file is for manually creating the token_usage table in Supabase
-- Execute this in the Supabase SQL Editor if the automatic creation script fails

-- Create extension for UUID generation if not exists
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create token_usage table
CREATE TABLE IF NOT EXISTS token_usage (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    discord_id TEXT NOT NULL,
    command TEXT,
    model TEXT,
    tokens INTEGER,
    estimated_cost FLOAT,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create RLS policies for the table
-- By default, we'll restrict all access and then allow specific operations

-- First, enable RLS on the table
ALTER TABLE token_usage ENABLE ROW LEVEL SECURITY;

-- Then create policies for each operation
-- Allow insert for authenticated users
CREATE POLICY "Allow users to insert their own usage data" 
ON token_usage FOR INSERT 
TO authenticated 
WITH CHECK (auth.uid()::text = discord_id OR auth.role() = 'service_role');

-- Allow select for authenticated users on their own data
CREATE POLICY "Allow users to view their own usage data" 
ON token_usage FOR SELECT 
TO authenticated 
USING (auth.uid()::text = discord_id OR auth.role() = 'service_role');

-- Create an additional policy for admins to view all data
CREATE POLICY "Allow admins to view all usage data"
ON token_usage FOR SELECT
TO authenticated
USING (auth.role() = 'service_role');