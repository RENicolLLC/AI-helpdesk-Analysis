from datetime import datetime
from sqlalchemy import Column, Integer, String, Text, Float, Boolean, DateTime, ForeignKey, JSON
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship

Base = declarative_base()

# Command Usage Tracking
class CommandUsage(Base):
    __tablename__ = 'command_usage'
    
    id = Column(Integer, primary_key=True)
    command_name = Column(String(50), nullable=False)  # e.g., 'ask', 'translate'
    discord_user_id = Column(String(20), nullable=False)
    server_id = Column(String(20), nullable=True)  # Discord server ID
    channel_id = Column(String(20), nullable=True)  # Discord channel ID
    complexity = Column(String(10), nullable=True)  # For /ask: low, medium, high
    model_used = Column(String(50), nullable=True)  # Which AI model was used
    tokens_used = Column(Integer, nullable=True)  # Track token usage
    execution_time_ms = Column(Integer, nullable=True)  # Performance tracking
    timestamp = Column(DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f"<CommandUsage(id={self.id}, command={self.command_name}, user={self.discord_user_id})>"

# Chat History for Context/Memory
class ChatMessage(Base):
    __tablename__ = 'chat_messages'
    
    id = Column(Integer, primary_key=True)
    discord_user_id = Column(String(20), nullable=False)
    conversation_id = Column(String(50), nullable=True)  # Group related messages
    role = Column(String(10), nullable=False)  # 'user' or 'assistant'
    content = Column(Text, nullable=False)
    model_used = Column(String(50), nullable=True)
    timestamp = Column(DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f"<ChatMessage(id={self.id}, user={self.discord_user_id}, role={self.role})>"

# User Profiles and Preferences
class UserProfile(Base):
    __tablename__ = 'user_profiles'
    
    id = Column(Integer, primary_key=True)
    discord_user_id = Column(String(20), nullable=False, unique=True)
    discord_username = Column(String(100), nullable=True)
    preferred_language = Column(String(10), nullable=True)  # Default language for translations
    preferred_model = Column(String(50), nullable=True)  # Default AI model
    opt_in_features = Column(JSON, nullable=True)  # Store user's opt-in preferences as JSON
    is_premium = Column(Boolean, default=False)  # Premium user status
    premium_tier = Column(Integer, default=0)  # 0=free, 1=basic, 2=premium, etc.
    tebex_customer_id = Column(String(50), nullable=True)  # For premium features
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f"<UserProfile(id={self.id}, discord_id={self.discord_user_id}, premium={self.is_premium})>"

# Token Usage Tracking
class TokenUsage(Base):
    __tablename__ = 'token_usage'
    
    id = Column(Integer, primary_key=True)
    date = Column(DateTime, default=datetime.utcnow)
    model = Column(String(50), nullable=False)  # e.g., 'gpt-3.5-turbo-0125', 'gpt-4o'
    prompt_tokens = Column(Integer, default=0)
    completion_tokens = Column(Integer, default=0)
    total_tokens = Column(Integer, default=0)
    estimated_cost_usd = Column(Float, default=0.0)  # Estimated cost
    
    def __repr__(self):
        return f"<TokenUsage(id={self.id}, date={self.date}, model={self.model}, tokens={self.total_tokens})>"

# User Reminders
class Reminder(Base):
    __tablename__ = 'reminders'
    
    id = Column(Integer, primary_key=True)
    discord_user_id = Column(String(20), nullable=False)
    content = Column(Text, nullable=False)
    set_at = Column(DateTime, default=datetime.utcnow)
    remind_at = Column(DateTime, nullable=False)  # When to remind the user
    completed = Column(Boolean, default=False)
    
    def __repr__(self):
        return f"<Reminder(id={self.id}, user={self.discord_user_id}, remind_at={self.remind_at})>"
