import os
import json
import logging
import requests
from dotenv import load_dotenv

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Load environment variables
load_dotenv()

# Get Supabase credentials
SUPABASE_URL = os.environ.get("SUPABASE_URL")
SUPABASE_KEY = os.environ.get("SUPABASE_KEY")
SUPABASE_SERVICE_ROLE_KEY = os.environ.get("SUPABASE_SERVICE_ROLE_KEY")

def create_tables():
    """Create tables in Supabase using REST API and service role key"""
    if not SUPABASE_URL or not SUPABASE_SERVICE_ROLE_KEY:
        logger.error("Supabase URL or Service Role Key not found in environment variables")
        return False
    
    try:
        # Headers for admin operations
        headers = {
            "apikey": SUPABASE_SERVICE_ROLE_KEY or SUPABASE_KEY,
            "Authorization": f"Bearer {SUPABASE_SERVICE_ROLE_KEY or SUPABASE_KEY}",
            "Content-Type": "application/json"
        }
        
        # Get the list of existing tables to check if our tables already exist
        response = requests.get(
            f"{SUPABASE_URL}/rest/v1/",
            headers=headers
        )
        
        logger.info(f"Response from Supabase: {response.status_code}")
        if response.status_code >= 400:
            logger.error(f"Connection error: {response.text}")
        
        # Create discord_users table if it doesn't exist
        # Using the SQL rpc endpoint
        sql_query = """
        CREATE TABLE IF NOT EXISTS discord_users (
            id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
            discord_id TEXT NOT NULL UNIQUE,
            username TEXT,
            premium BOOLEAN DEFAULT FALSE,
            premium_tier INTEGER DEFAULT 0,
            preferences JSONB DEFAULT '{"preferred_language": "en", "preferred_model": "gpt-3.5-turbo-0125"}',
            opt_in_features JSONB DEFAULT '{"notifications": false, "beta_features": false}',
            tebex_customer_id TEXT,
            created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
            updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
        );
        
        CREATE TABLE IF NOT EXISTS token_usage (
            id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
            discord_id TEXT NOT NULL,
            command TEXT,
            model TEXT,
            tokens INTEGER,
            estimated_cost FLOAT,
            timestamp TIMESTAMP WITH TIME ZONE DEFAULT now()
        );
        
        CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
        """
        
        # Attempt to execute the SQL directly
        sql_request_data = {"query": sql_query}
        response = requests.post(
            f"{SUPABASE_URL}/rest/v1/rpc/execute_sql",
            json=sql_request_data,
            headers=headers
        )
        
        if response.status_code == 404:
            # Try alternative endpoint
            response = requests.post(
                f"{SUPABASE_URL}/rest/v1/rpc/execute",
                json={"sql": sql_query},
                headers=headers
            )
            
        logger.info(f"Create tables response: {response.status_code}")
        if response.status_code >= 400:
            logger.error(f"Error creating tables: {response.text}")
            
            # Log SQL for manual creation
            logger.info("Please run this SQL in the Supabase SQL Editor to create tables manually:")
            logger.info(sql_query)
            return False
        
        logger.info("Tables created successfully")
        return True
    except Exception as e:
        logger.error(f"Error creating tables: {e}")
        return False

def test_tables():
    """Test if tables were created and can be accessed"""
    if not SUPABASE_URL or not SUPABASE_KEY:
        logger.error("Supabase URL or API Key not found in environment variables")
        return False
    
    try:
        headers = {
            "apikey": SUPABASE_KEY,
            "Authorization": f"Bearer {SUPABASE_KEY}",
            "Content-Type": "application/json"
        }
        
        # Try to access discord_users table
        response = requests.get(
            f"{SUPABASE_URL}/rest/v1/discord_users?limit=1",
            headers=headers
        )
        
        # Check response (404 means table doesn't exist, 200 means it exists but might be empty)
        if response.status_code == 200:
            logger.info("✅ discord_users table exists and is accessible")
            records = response.json()
            logger.info(f"Found {len(records)} existing users")
        elif response.status_code == 404:
            logger.error("❌ discord_users table does not exist")
            return False
        else:
            logger.error(f"❌ Error accessing discord_users table: {response.status_code} - {response.text}")
            return False
        
        # Try to access token_usage table
        response = requests.get(
            f"{SUPABASE_URL}/rest/v1/token_usage?limit=1",
            headers=headers
        )
        
        if response.status_code == 200:
            logger.info("✅ token_usage table exists and is accessible")
            records = response.json()
            logger.info(f"Found {len(records)} existing token usage records")
        elif response.status_code == 404:
            logger.error("❌ token_usage table does not exist")
            return False
        else:
            logger.error(f"❌ Error accessing token_usage table: {response.status_code} - {response.text}")
            return False
        
        return True
    except Exception as e:
        logger.error(f"Error testing tables: {e}")
        return False

def main():
    logger.info("Starting Supabase table setup...")
    
    # Try to create tables first
    created = create_tables()
    
    # Then test if tables are accessible
    test_tables()
    
    logger.info("Supabase table setup complete")

if __name__ == "__main__":
    main()