import asyncio
import logging
import trafilatura
from typing import Optional, Tuple
import aiohttp
from urllib.parse import urlparse

logger = logging.getLogger("bot.web_scraper")

async def get_website_text_content(url: str) -> Optional[str]:
    """
    This function takes a url and asynchronously returns the main text content of the website.
    The text content is extracted using trafilatura for better readability.
    
    Args:
        url: The URL of the website to scrape
        
    Returns:
        The extracted text content, or None if extraction failed
    """
    try:
        logger.info(f"Scraping content from URL: {url}")
        
        # Validate URL
        parsed_url = urlparse(url)
        if not parsed_url.scheme or not parsed_url.netloc:
            logger.error(f"Invalid URL: {url}")
            return None
        
        # Fetch the website content asynchronously
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=30) as response:
                if response.status != 200:
                    logger.error(f"Failed to fetch URL: {url}, status code: {response.status}")
                    return None
                
                html_content = await response.text()
        
        # Extract the text content using trafilatura
        # This needs to run in a thread since trafilatura is synchronous
        text_content = await asyncio.to_thread(
            trafilatura.extract,
            html_content,
            include_comments=False,
            include_tables=True,
            no_fallback=False
        )
        
        if not text_content:
            logger.warning(f"Could not extract text from URL: {url}")
            return None
        
        logger.info(f"Successfully extracted content from URL: {url}")
        return text_content
    except Exception as e:
        logger.error(f"Error scraping website: {e}")
        return None
