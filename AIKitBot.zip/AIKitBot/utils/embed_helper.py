import discord
from typing import Optional
from datetime import datetime

def create_response_embed(
    title: str,
    description: str,
    user: discord.User,
    color: discord.Color = discord.Color.blue(),
    footer: Optional[str] = None
) -> discord.Embed:
    """
    Create a Discord embed for bot responses.
    
    Args:
        title: The title of the embed
        description: The main content of the embed
        user: The user who triggered the response
        color: The color of the embed
        footer: Optional footer text
        
    Returns:
        A formatted Discord embed
    """
    # Create the embed
    embed = discord.Embed(
        title=title,
        description=description,
        color=color,
        timestamp=datetime.now()
    )
    
    # Add user information
    embed.set_author(
        name=f"Requested by {user.display_name}",
        icon_url=user.display_avatar.url
    )
    
    # Add footer if provided
    if footer:
        embed.set_footer(text=footer)
    else:
        embed.set_footer(text="AI Assistant")
    
    return embed
