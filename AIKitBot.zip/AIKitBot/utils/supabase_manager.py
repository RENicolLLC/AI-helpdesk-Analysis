import os
import logging
import json
from typing import Dict, List, Optional, Any

from supabase import create_client, Client

logger = logging.getLogger(__name__)

# These environment variables will need to be set for Supabase
# Try both os.environ.get and os.getenv to ensure we get the values
SUPABASE_URL = os.environ.get("SUPABASE_URL", "") or os.getenv("SUPABASE_URL", "")
SUPABASE_KEY = os.environ.get("SUPABASE_KEY", "") or os.getenv("SUPABASE_KEY", "")
SUPABASE_SERVICE_ROLE_KEY = os.environ.get("SUPABASE_SERVICE_ROLE_KEY", "") or os.getenv("SUPABASE_SERVICE_ROLE_KEY", "")

# Initialize Supabase client
supabase: Optional[Client] = None

def init_supabase():
    """Initialize Supabase client if credentials are available"""
    global supabase
    
    # Add debug logging to help diagnose issues
    logger.info(f"Initializing Supabase with URL available: {bool(SUPABASE_URL)}, KEY available: {bool(SUPABASE_KEY)}")
    
    if SUPABASE_URL and SUPABASE_KEY:
        try:
            supabase = create_client(SUPABASE_URL, SUPABASE_KEY)
            if supabase:
                logger.info("Supabase client initialized successfully")
                return True
            else:
                logger.error("Supabase client is None after initialization attempt")
                return False
        except Exception as e:
            logger.error(f"Error initializing Supabase client: {e}")
            return False
    else:
        logger.warning("Supabase credentials not found, premium features will be limited")
        if SUPABASE_URL:
            logger.debug(f"SUPABASE_URL: {SUPABASE_URL[:5]}... (truncated)")
        if SUPABASE_KEY:
            logger.debug(f"SUPABASE_KEY: {SUPABASE_KEY[:5]}... (truncated)")
        return False

async def get_user_profile(discord_id: str) -> Dict[str, Any]:
    """Get user profile from Supabase"""
    if not supabase:
        logger.warning("Supabase client not initialized")
        return {"discord_id": discord_id, "premium": False}
    
    try:
        response = supabase.table("discord_users").select("*").eq("discord_id", discord_id).execute()
        
        if response.data and len(response.data) > 0:
            return response.data[0]
        else:
            # User not found, create basic profile
            return await create_user_profile(discord_id)
    except Exception as e:
        logger.error(f"Error getting user profile from Supabase: {e}")
        return {"discord_id": discord_id, "premium": False}

async def create_user_profile(discord_id: str, username: Optional[str] = None) -> Dict[str, Any]:
    """Create a new user profile in Supabase"""
    if not supabase:
        logger.warning("Supabase client not initialized")
        return {"discord_id": discord_id, "premium": False}
    
    try:
        user_data = {
            "discord_id": discord_id,
            "username": username,
            "premium": False,
            "premium_tier": 0,
            "preferences": json.dumps({
                "preferred_language": "en",
                "preferred_model": "gpt-3.5-turbo-0125"
            }),
            "opt_in_features": json.dumps({
                "notifications": False,
                "beta_features": False
            })
        }
        
        response = supabase.table("discord_users").insert(user_data).execute()
        
        if response.data and len(response.data) > 0:
            logger.info(f"Created new user profile for Discord user {discord_id} in Supabase")
            return response.data[0]
        else:
            logger.error(f"Failed to create user profile in Supabase for Discord user {discord_id}")
            return {"discord_id": discord_id, "premium": False}
    except Exception as e:
        logger.error(f"Error creating user profile in Supabase: {e}")
        return {"discord_id": discord_id, "premium": False}

async def update_user_profile(discord_id: str, updates: Dict[str, Any]) -> bool:
    """Update user profile in Supabase"""
    if not supabase:
        logger.warning("Supabase client not initialized")
        return False
    
    try:
        response = supabase.table("discord_users").update(updates).eq("discord_id", discord_id).execute()
        
        if response.data and len(response.data) > 0:
            logger.info(f"Updated user profile for Discord user {discord_id} in Supabase")
            return True
        else:
            logger.error(f"Failed to update user profile in Supabase for Discord user {discord_id}")
            return False
    except Exception as e:
        logger.error(f"Error updating user profile in Supabase: {e}")
        return False

async def log_token_usage_to_supabase(discord_id: str, command: str, model: str, tokens: int, estimated_cost: float) -> bool:
    """Log token usage to Supabase for billing and analytics"""
    if not supabase:
        logger.warning("Supabase client not initialized")
        return False
    
    try:
        token_data = {
            "discord_id": discord_id,
            "command": command,
            "model": model,
            "tokens": tokens,
            "estimated_cost": estimated_cost,
            "timestamp": "now()"
        }
        
        response = supabase.table("token_usage").insert(token_data).execute()
        
        if response.data and len(response.data) > 0:
            return True
        else:
            logger.error(f"Failed to log token usage in Supabase for Discord user {discord_id}")
            return False
    except Exception as e:
        logger.error(f"Error logging token usage in Supabase: {e}")
        return False

async def check_premium_status(discord_id: str) -> Dict[str, Any]:
    """Check if a user has premium status and what tier"""
    if not supabase:
        logger.warning("Supabase client not initialized")
        return {"is_premium": False, "tier": 0}
    
    try:
        response = supabase.table("discord_users").select("premium, premium_tier, tebex_customer_id").eq("discord_id", discord_id).execute()
        
        if response.data and len(response.data) > 0:
            user_data = response.data[0]
            return {
                "is_premium": user_data.get("premium", False),
                "tier": user_data.get("premium_tier", 0),
                "tebex_id": user_data.get("tebex_customer_id")
            }
        else:
            return {"is_premium": False, "tier": 0}
    except Exception as e:
        logger.error(f"Error checking premium status in Supabase: {e}")
        return {"is_premium": False, "tier": 0}

async def get_user_preference(discord_id: str, preference_key: str) -> Any:
    """Get a specific user preference"""
    if not supabase:
        logger.warning("Supabase client not initialized")
        return None
    
    try:
        response = supabase.table("discord_users").select("preferences").eq("discord_id", discord_id).execute()
        
        if response.data and len(response.data) > 0 and "preferences" in response.data[0]:
            preferences = json.loads(response.data[0]["preferences"])
            return preferences.get(preference_key)
        return None
    except Exception as e:
        logger.error(f"Error getting user preference from Supabase: {e}")
        return None

async def set_user_preference(discord_id: str, preference_key: str, preference_value: Any) -> bool:
    """Set a specific user preference"""
    if not supabase:
        logger.warning("Supabase client not initialized")
        return False
    
    try:
        # First get existing preferences
        response = supabase.table("discord_users").select("preferences").eq("discord_id", discord_id).execute()
        
        if response.data and len(response.data) > 0 and "preferences" in response.data[0]:
            preferences = json.loads(response.data[0]["preferences"])
        else:
            preferences = {}
        
        # Update the preference
        preferences[preference_key] = preference_value
        
        # Save back to Supabase
        update_response = supabase.table("discord_users").update({
            "preferences": json.dumps(preferences)
        }).eq("discord_id", discord_id).execute()
        
        if update_response.data and len(update_response.data) > 0:
            return True
        return False
    except Exception as e:
        logger.error(f"Error setting user preference in Supabase: {e}")
        return False
