import asyncio
import logging
import discord
from datetime import datetime
from typing import Dict, List, Optional, Any

from utils.db_manager import get_due_reminders, mark_reminder_complete

logger = logging.getLogger(__name__)

async def reminder_check_task(bot: discord.Client):
    """Background task to check for due reminders and send them to users."""
    await bot.wait_until_ready()
    logger.info("Reminder check task started")
    
    while not bot.is_closed():
        try:
            # Get all reminders that are due
            due_reminders = await get_due_reminders()
            
            for reminder in due_reminders:
                try:
                    # Get the user to send the reminder to
                    user_id = int(reminder['discord_user_id'])
                    user = bot.get_user(user_id)
                    
                    if user:
                        # Create an embed for the reminder
                        embed = discord.Embed(
                            title="Reminder",
                            description=reminder['content'],
                            color=discord.Color.blue(),
                            timestamp=datetime.utcnow()
                        )
                        
                        # Add when the reminder was set
                        set_at = datetime.fromisoformat(reminder['set_at'].replace('Z', '+00:00'))
                        embed.add_field(
                            name="Set",
                            value=f"<t:{int(set_at.timestamp())}:R>",
                            inline=True
                        )
                        
                        # Send the reminder to the user
                        try:
                            await user.send(embed=embed)
                            logger.info(f"Sent reminder {reminder['id']} to user {user_id}")
                        except discord.Forbidden:
                            logger.warning(f"Cannot send reminder to user {user_id} (DMs closed)")
                        except Exception as e:
                            logger.error(f"Error sending reminder to user {user_id}: {e}")
                    else:
                        logger.warning(f"User {user_id} not found for reminder {reminder['id']}")
                    
                    # Mark the reminder as completed
                    await mark_reminder_complete(reminder['id'])
                    
                except Exception as inner_e:
                    logger.error(f"Error processing reminder {reminder['id']}: {inner_e}")
            
            # Check for new reminders every minute
            await asyncio.sleep(60)
            
        except Exception as e:
            logger.error(f"Error in reminder check task: {e}")
            # Don't crash the task, just wait and try again
            await asyncio.sleep(60)

def start_reminder_task(bot: discord.Client):
    """Start the background task to check for reminders."""
    bot.loop.create_task(reminder_check_task(bot))
