import logging
import time
import functools
from typing import Callable, Optional, Dict, Any, List

import discord
from discord import app_commands
from discord.ext import commands

from utils.db_manager import log_command_usage, get_or_create_user_profile
from utils.supabase_manager import check_premium_status

logger = logging.getLogger(__name__)

# Command decorator that logs usage and tracks performance
def log_command(command_name: Optional[str] = None):
    """Decorator to log command usage to the database and track performance"""
    def decorator(func):
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            # Extract interaction from args (usually the first argument after self)
            interaction = None
            for arg in args:
                if isinstance(arg, discord.Interaction):
                    interaction = arg
                    break
            
            # If no interaction was found, check kwargs
            if not interaction and 'interaction' in kwargs:
                interaction = kwargs['interaction']
            
            if not interaction:
                logger.warning(f"No interaction found for command {command_name or func.__name__}")
                return await func(*args, **kwargs)
            
            # Extract command parameters for logging
            cmd_name = command_name or func.__name__.replace('_command', '')
            user_id = str(interaction.user.id)
            server_id = str(interaction.guild_id) if interaction.guild else None
            channel_id = str(interaction.channel_id) if interaction.channel else None
            
            # Get complexity parameter if it exists
            complexity = None
            for param_name, param_value in kwargs.items():
                if param_name == 'complexity' and isinstance(param_value, str):
                    complexity = param_value
            
            # Measure execution time
            start_time = time.time()
            
            try:
                # Execute the command
                result = await func(*args, **kwargs)
                
                # Calculate execution time
                execution_time_ms = int((time.time() - start_time) * 1000)
                
                # Log the command usage asynchronously
                await log_command_usage(
                    command_name=cmd_name,
                    discord_user_id=user_id,
                    server_id=server_id,
                    channel_id=channel_id,
                    complexity=complexity,
                    execution_time_ms=execution_time_ms
                )
                
                return result
            except Exception as e:
                # Log the error
                logger.error(f"Error executing command {cmd_name}: {e}")
                # Still try to log the failed command
                execution_time_ms = int((time.time() - start_time) * 1000)
                await log_command_usage(
                    command_name=cmd_name,
                    discord_user_id=user_id,
                    server_id=server_id,
                    channel_id=channel_id,
                    complexity=complexity,
                    execution_time_ms=execution_time_ms
                )
                # Re-raise the exception
                raise
        
        return wrapper
    return decorator

# Premium-only command decorator
def premium_only():
    """Decorator to restrict commands to premium users only"""
    def decorator(func):
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            # Extract interaction from args (usually the first argument after self)
            interaction = None
            for arg in args:
                if isinstance(arg, discord.Interaction):
                    interaction = arg
                    break
            
            # If no interaction was found, check kwargs
            if not interaction and 'interaction' in kwargs:
                interaction = kwargs['interaction']
            
            if not interaction:
                logger.warning(f"No interaction found for premium command {func.__name__}")
                return await func(*args, **kwargs)
            
            # Check if user has premium status
            user_id = str(interaction.user.id)
            premium_status = await check_premium_status(user_id)
            
            if not premium_status.get('is_premium', False):
                # User doesn't have premium status, send an error message
                premium_embed = discord.Embed(
                    title="Premium Feature",
                    description="This command is only available to premium users. Get premium to access this feature.",
                    color=discord.Color.gold()
                )
                premium_embed.add_field(
                    name="Why Premium?",
                    value="Premium users get access to advanced features, higher rate limits, and priority support.",
                    inline=False
                )
                premium_embed.set_footer(text="Upgrade to premium to unlock all features!")
                
                await interaction.response.send_message(embed=premium_embed, ephemeral=True)
                return None
            
            # User has premium, proceed with the command
            return await func(*args, **kwargs)
        
        return wrapper
    return decorator

# Decorator to apply user preferences
def with_user_preferences():
    """Decorator to fetch and apply user preferences before executing a command"""
    def decorator(func):
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            # Extract interaction from args (usually the first argument after self)
            interaction = None
            for arg in args:
                if isinstance(arg, discord.Interaction):
                    interaction = arg
                    break
            
            # If no interaction was found, check kwargs
            if not interaction and 'interaction' in kwargs:
                interaction = kwargs['interaction']
            
            if not interaction:
                logger.warning(f"No interaction found for command with preferences {func.__name__}")
                return await func(*args, **kwargs)
            
            # Get user profile and preferences
            user_id = str(interaction.user.id)
            user_profile = await get_or_create_user_profile(
                discord_user_id=user_id,
                discord_username=interaction.user.name
            )
            
            # Apply preferences to kwargs if not explicitly provided
            if 'preferred_language' in user_profile and user_profile['preferred_language'] and 'language' not in kwargs:
                kwargs['language'] = user_profile['preferred_language']
            
            if 'preferred_model' in user_profile and user_profile['preferred_model'] and 'model' not in kwargs:
                kwargs['model'] = user_profile['preferred_model']
            
            # Execute the command with applied preferences
            return await func(*args, **kwargs)
        
        return wrapper
    return decorator