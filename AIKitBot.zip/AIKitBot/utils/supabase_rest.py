import os
import json
import logging
import requests
from typing import Dict, List, Optional, Any

# Configure logging
logger = logging.getLogger(__name__)

# Get Supabase credentials from environment
SUPABASE_URL = os.environ.get("SUPABASE_URL", "") or os.getenv("SUPABASE_URL", "")
SUPABASE_KEY = os.environ.get("SUPABASE_KEY", "") or os.getenv("SUPABASE_KEY", "")
SUPABASE_SERVICE_ROLE_KEY = os.environ.get("SUPABASE_SERVICE_ROLE_KEY", "") or os.getenv("SUPABASE_SERVICE_ROLE_KEY", "")

# Track if Supabase connection is working
supabase_initialized = False

def init_supabase():
    """Check Supabase connection by making a simple API call"""
    global supabase_initialized
    
    logger.info(f"Initializing Supabase REST with URL available: {bool(SUPABASE_URL)}, KEY available: {bool(SUPABASE_KEY)}")
    
    if not SUPABASE_URL or not SUPABASE_KEY:
        logger.warning("Supabase credentials not found, premium features will be limited")
        return False
    
    # Test the connection with a simple health check
    try:
        headers = {
            "apikey": SUPABASE_KEY,
            "Authorization": f"Bearer {SUPABASE_KEY}"
        }
        
        # Try to access a table to see if auth works
        response = requests.get(
            f"{SUPABASE_URL}/rest/v1/discord_users?limit=1",
            headers=headers
        )
        
        # 200 = Success, 404 = Table not found (but auth worked)
        if response.status_code in [200, 404]:
            logger.info("Supabase REST connection successful")
            supabase_initialized = True
            return True
        else:
            logger.error(f"Supabase REST connection failed with status code {response.status_code}: {response.text}")
            return False
    except Exception as e:
        logger.error(f"Error connecting to Supabase: {e}")
        return False

async def get_user_profile(discord_id: str) -> Dict[str, Any]:
    """Get user profile from Supabase using REST API"""
    if not supabase_initialized:
        logger.warning("Supabase not initialized")
        return {"discord_id": discord_id, "premium": False}
    
    try:
        headers = {
            "apikey": SUPABASE_KEY,
            "Authorization": f"Bearer {SUPABASE_KEY}"
        }
        
        response = requests.get(
            f"{SUPABASE_URL}/rest/v1/discord_users?discord_id=eq.{discord_id}&limit=1",
            headers=headers
        )
        
        if response.status_code == 200 and response.json():
            return response.json()[0]
        else:
            # User not found, create basic profile
            return await create_user_profile(discord_id)
    except Exception as e:
        logger.error(f"Error getting user profile from Supabase: {e}")
        return {"discord_id": discord_id, "premium": False}

async def create_user_profile(discord_id: str, username: Optional[str] = None) -> Dict[str, Any]:
    """Create a new user profile in Supabase using REST API"""
    if not supabase_initialized:
        logger.warning("Supabase not initialized")
        return {"discord_id": discord_id, "premium": False}
    
    try:
        user_data = {
            "discord_id": discord_id,
            "username": username,
            "premium": False,
            "premium_tier": 0,
            "preferences": json.dumps({
                "preferred_language": "en",
                "preferred_model": "gpt-3.5-turbo-0125"
            }),
            "opt_in_features": json.dumps({
                "notifications": False,
                "beta_features": False
            })
        }
        
        headers = {
            "apikey": SUPABASE_KEY,
            "Authorization": f"Bearer {SUPABASE_KEY}",
            "Content-Type": "application/json",
            "Prefer": "return=representation"
        }
        
        response = requests.post(
            f"{SUPABASE_URL}/rest/v1/discord_users",
            json=user_data,
            headers=headers
        )
        
        if response.status_code == 201 and response.json():
            logger.info(f"Created new user profile for Discord user {discord_id} in Supabase")
            return response.json()[0]
        else:
            logger.error(f"Failed to create user profile in Supabase for Discord user {discord_id}: {response.status_code} - {response.text}")
            return {"discord_id": discord_id, "premium": False}
    except Exception as e:
        logger.error(f"Error creating user profile in Supabase: {e}")
        return {"discord_id": discord_id, "premium": False}

async def update_user_profile(discord_id: str, updates: Dict[str, Any]) -> bool:
    """Update user profile in Supabase using REST API"""
    if not supabase_initialized:
        logger.warning("Supabase not initialized")
        return False
    
    try:
        headers = {
            "apikey": SUPABASE_KEY,
            "Authorization": f"Bearer {SUPABASE_KEY}",
            "Content-Type": "application/json",
            "Prefer": "return=representation"
        }
        
        response = requests.patch(
            f"{SUPABASE_URL}/rest/v1/discord_users?discord_id=eq.{discord_id}",
            json=updates,
            headers=headers
        )
        
        if response.status_code == 200 and response.json():
            logger.info(f"Updated user profile for Discord user {discord_id} in Supabase")
            return True
        else:
            logger.error(f"Failed to update user profile in Supabase for Discord user {discord_id}: {response.status_code} - {response.text}")
            return False
    except Exception as e:
        logger.error(f"Error updating user profile in Supabase: {e}")
        return False

async def log_token_usage_to_supabase(discord_id: str, command: str, model: str, tokens: int, estimated_cost: float) -> bool:
    """Log token usage to Supabase for billing and analytics using REST API"""
    if not supabase_initialized:
        logger.warning("Supabase not initialized")
        return False
    
    try:
        token_data = {
            "discord_id": discord_id,
            "command": command,
            "model": model,
            "tokens": tokens,
            "estimated_cost": estimated_cost
        }
        
        headers = {
            "apikey": SUPABASE_KEY,
            "Authorization": f"Bearer {SUPABASE_KEY}",
            "Content-Type": "application/json",
            "Prefer": "return=representation"
        }
        
        response = requests.post(
            f"{SUPABASE_URL}/rest/v1/token_usage",
            json=token_data,
            headers=headers
        )
        
        if response.status_code == 201:
            return True
        else:
            logger.error(f"Failed to log token usage in Supabase for Discord user {discord_id}: {response.status_code} - {response.text}")
            return False
    except Exception as e:
        logger.error(f"Error logging token usage in Supabase: {e}")
        return False

async def check_premium_status(discord_id: str) -> Dict[str, Any]:
    """Check if a user has premium status and what tier using REST API"""
    if not supabase_initialized:
        logger.warning("Supabase not initialized")
        return {"is_premium": False, "tier": 0}
    
    try:
        headers = {
            "apikey": SUPABASE_KEY,
            "Authorization": f"Bearer {SUPABASE_KEY}"
        }
        
        response = requests.get(
            f"{SUPABASE_URL}/rest/v1/discord_users?discord_id=eq.{discord_id}&select=premium,premium_tier,tebex_customer_id",
            headers=headers
        )
        
        if response.status_code == 200 and response.json():
            user_data = response.json()[0]
            return {
                "is_premium": user_data.get("premium", False),
                "tier": user_data.get("premium_tier", 0),
                "tebex_id": user_data.get("tebex_customer_id")
            }
        else:
            return {"is_premium": False, "tier": 0}
    except Exception as e:
        logger.error(f"Error checking premium status in Supabase: {e}")
        return {"is_premium": False, "tier": 0}

async def get_user_preference(discord_id: str, preference_key: str) -> Any:
    """Get a specific user preference using REST API"""
    if not supabase_initialized:
        logger.warning("Supabase not initialized")
        return None
    
    try:
        headers = {
            "apikey": SUPABASE_KEY,
            "Authorization": f"Bearer {SUPABASE_KEY}"
        }
        
        response = requests.get(
            f"{SUPABASE_URL}/rest/v1/discord_users?discord_id=eq.{discord_id}&select=preferences",
            headers=headers
        )
        
        if response.status_code == 200 and response.json() and "preferences" in response.json()[0]:
            preferences = json.loads(response.json()[0]["preferences"])
            return preferences.get(preference_key)
        return None
    except Exception as e:
        logger.error(f"Error getting user preference from Supabase: {e}")
        return None

async def set_user_preference(discord_id: str, preference_key: str, preference_value: Any) -> bool:
    """Set a specific user preference using REST API"""
    if not supabase_initialized:
        logger.warning("Supabase not initialized")
        return False
    
    try:
        # First get existing preferences
        headers = {
            "apikey": SUPABASE_KEY,
            "Authorization": f"Bearer {SUPABASE_KEY}"
        }
        
        response = requests.get(
            f"{SUPABASE_URL}/rest/v1/discord_users?discord_id=eq.{discord_id}&select=preferences",
            headers=headers
        )
        
        if response.status_code == 200 and response.json() and "preferences" in response.json()[0]:
            preferences = json.loads(response.json()[0]["preferences"])
        else:
            preferences = {}
        
        # Update the preference
        preferences[preference_key] = preference_value
        
        # Save back to Supabase
        update_headers = {
            "apikey": SUPABASE_KEY,
            "Authorization": f"Bearer {SUPABASE_KEY}",
            "Content-Type": "application/json",
            "Prefer": "return=representation"
        }
        
        update_response = requests.patch(
            f"{SUPABASE_URL}/rest/v1/discord_users?discord_id=eq.{discord_id}",
            json={"preferences": json.dumps(preferences)},
            headers=update_headers
        )
        
        if update_response.status_code == 200 and update_response.json():
            return True
        return False
    except Exception as e:
        logger.error(f"Error setting user preference in Supabase: {e}")
        return False

# Initialize Supabase when this module is imported
init_supabase()