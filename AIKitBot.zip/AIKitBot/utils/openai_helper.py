import os
import json
import asyncio
import logging
from typing import List, Dict, Optional, Any

# the newest OpenAI model is "gpt-4o" which was released May 13, 2024.
# do not change this unless explicitly requested by the user
from openai import OpenAI, AsyncOpenAI

logger = logging.getLogger("bot.openai_helper")

# Initialize the OpenAI client
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
if not OPENAI_API_KEY:
    raise ValueError("OPENAI_API_KEY not found in environment variables")

# Initialize both sync and async clients
openai_client = OpenAI(api_key=OPENAI_API_KEY)
async_openai_client = AsyncOpenAI(api_key=OPENAI_API_KEY)

# Available OpenAI models
AVAILABLE_MODELS = [
    "gpt-3.5-turbo-0125",  # Cost-effective default model for simple tasks
    "gpt-3.5-turbo",       # Fallback for 3.5
    "gpt-4o",              # More powerful but more expensive
    "gpt-4-turbo",         # Alternative powerful model
    "gpt-4",               # Original GPT-4
]

def get_openai_models() -> List[str]:
    """Get the list of available OpenAI models."""
    return AVAILABLE_MODELS

def select_appropriate_model(task_type: str = "general", complexity: str = "low") -> str:
    """
    Select the appropriate OpenAI model based on task type and complexity.
    
    Args:
        task_type: The type of task (general, code, translation, summarization, etc.)
        complexity: The complexity level (low, medium, high)
        
    Returns:
        The name of the model to use
    """
    # For high complexity tasks, use the more powerful model
    if complexity.lower() == "high":
        return "gpt-4o"  # Use the most powerful model for complex tasks
    
    # For code-related tasks that are medium complexity
    if task_type.lower() == "code" and complexity.lower() == "medium":
        return "gpt-4o"  # Programming often benefits from better reasoning
    
    # For everything else, use the cost-effective model
    return "gpt-3.5-turbo-0125"

async def generate_chat_response(
    prompt: str,
    system_prompt: Optional[str] = "You are a helpful assistant that provides clear, concise, and accurate responses.",
    model: str = "gpt-3.5-turbo-0125",
    max_tokens: int = 1000,
    task_type: str = "general",
    complexity: str = "low"
) -> str:
    """Generate a response using OpenAI's ChatCompletion API.
    
    Args:
        prompt: The user's prompt or question
        system_prompt: Optional system prompt to guide the AI's behavior
        model: The OpenAI model to use (default: gpt-4o)
        max_tokens: Maximum tokens in the response
        
    Returns:
        The generated response as a string
    """
    try:
        # If model is set to the default, select appropriate model based on task type and complexity
        if model == "gpt-3.5-turbo-0125":
            model = select_appropriate_model(task_type, complexity)
            logger.info(f"Selected model {model} based on task type {task_type} and complexity {complexity}")
        # Check if the model is valid
        elif model not in AVAILABLE_MODELS:
            logger.warning(f"Invalid model {model}, falling back to gpt-3.5-turbo-0125")
            model = "gpt-3.5-turbo-0125"
        
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": prompt}
        ]
        
        logger.info(f"Generating response using model {model}")
        
        # Make an async request to the OpenAI API
        response = await async_openai_client.chat.completions.create(
            model=model,
            messages=messages,
            max_tokens=max_tokens,
            temperature=0.7
        )
        
        # Extract and return the response text
        return response.choices[0].message.content
    except Exception as e:
        logger.error(f"Error generating chat response: {e}")
        raise

async def transcribe_audio(audio_file_path: str) -> str:
    """Transcribe an audio file using OpenAI's Whisper API.
    
    Args:
        audio_file_path: Path to the audio file
        
    Returns:
        The transcribed text
    """
    try:
        logger.info(f"Transcribing audio file: {audio_file_path}")
        
        # Use the synchronous client for transcription since it's file-based
        # But wrap it in asyncio.to_thread to make it non-blocking
        with open(audio_file_path, "rb") as audio_file:
            response = await asyncio.to_thread(
                openai_client.audio.transcriptions.create,
                model="whisper-1", 
                file=audio_file
            )
        
        return response.text
    except Exception as e:
        logger.error(f"Error transcribing audio: {e}")
        raise

async def translate_text(text: str, target_language: str) -> str:
    """Translate text to a target language using OpenAI.
    
    Args:
        text: The text to translate
        target_language: The target language
        
    Returns:
        The translated text
    """
    try:
        logger.info(f"Translating text to {target_language}")
        
        # Create a prompt for translation
        prompt = f"Translate the following text to {target_language}:\n\n{text}"
        
        # Use ChatGPT to translate (using the cost-effective model)
        response = await async_openai_client.chat.completions.create(
            model="gpt-3.5-turbo-0125",
            messages=[
                {"role": "system", "content": "You are a helpful translator. Translate the text accurately without adding any extra information or comments."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=1000,
            temperature=0.3
        )
        
        return response.choices[0].message.content
    except Exception as e:
        logger.error(f"Error translating text: {e}")
        raise

async def summarize_website_content(content: str, max_length: int = 1500) -> str:
    """Summarize website content using OpenAI.
    
    Args:
        content: The website content to summarize
        max_length: Maximum length of content to send to OpenAI
        
    Returns:
        The summarized content
    """
    try:
        logger.info("Summarizing website content")
        
        # Truncate the content if it's too long
        if len(content) > max_length:
            content = content[:max_length] + "..."
        
        # Create a prompt for summarization
        prompt = f"Please provide a concise summary of the following website content:\n\n{content}"
        
        # Use ChatGPT to summarize (using the cost-effective model)
        response = await async_openai_client.chat.completions.create(
            model="gpt-3.5-turbo-0125",
            messages=[
                {"role": "system", "content": "You are a helpful assistant that summarizes website content clearly and concisely, highlighting the most important information."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=500,
            temperature=0.5
        )
        
        return response.choices[0].message.content
    except Exception as e:
        logger.error(f"Error summarizing website content: {e}")
        raise
