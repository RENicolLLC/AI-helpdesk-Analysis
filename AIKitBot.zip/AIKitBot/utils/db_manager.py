import os
import json
import logging
import asyncio
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Union, Any

from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, scoped_session
from sqlalchemy.exc import SQLAlchemyError

from models.database import Base, CommandUsage, ChatMessage, UserProfile, TokenUsage, Reminder

logger = logging.getLogger(__name__)

# Get database URL from environment variables
DATABASE_URL = os.environ.get("DATABASE_URL")

# Setup SQLAlchemy engine and session
engine = create_engine(
    DATABASE_URL,
    pool_pre_ping=True,  # Verify connection before using
    pool_recycle=300,    # Recycle connections every 5 minutes
    echo=False           # Set to True for verbose logging
)

# Create a scoped session factory
SessionLocal = scoped_session(sessionmaker(autocommit=False, autoflush=False, bind=engine))

# Initialize database tables
def init_db():
    try:
        # Create all tables if they don't exist
        Base.metadata.create_all(engine)
        logger.info("Database tables created successfully")
    except Exception as e:
        logger.error(f"Error initializing database: {e}")
        raise

# Command Usage Tracking Functions
async def log_command_usage(
    command_name: str,
    discord_user_id: str,
    server_id: Optional[str] = None,
    channel_id: Optional[str] = None,
    complexity: Optional[str] = None,
    model_used: Optional[str] = None,
    tokens_used: Optional[int] = None,
    execution_time_ms: Optional[int] = None
) -> None:
    """Log command usage to the database"""
    try:
        session = SessionLocal()
        
        # Create a new command usage record
        command_usage = CommandUsage(
            command_name=command_name,
            discord_user_id=discord_user_id,
            server_id=server_id,
            channel_id=channel_id,
            complexity=complexity,
            model_used=model_used,
            tokens_used=tokens_used,
            execution_time_ms=execution_time_ms,
            timestamp=datetime.utcnow()
        )
        
        session.add(command_usage)
        session.commit()
        logger.debug(f"Logged command usage: {command_name} by user {discord_user_id}")
    except SQLAlchemyError as e:
        logger.error(f"Error logging command usage: {e}")
        session.rollback()
    finally:
        session.close()

# Chat History Functions
async def save_chat_message(
    discord_user_id: str,
    role: str,  # 'user' or 'assistant'
    content: str,
    conversation_id: Optional[str] = None,
    model_used: Optional[str] = None
) -> None:
    """Save a chat message to provide context/memory"""
    try:
        session = SessionLocal()
        
        # Create a new chat message
        message = ChatMessage(
            discord_user_id=discord_user_id,
            conversation_id=conversation_id,
            role=role,
            content=content,
            model_used=model_used,
            timestamp=datetime.utcnow()
        )
        
        session.add(message)
        session.commit()
    except SQLAlchemyError as e:
        logger.error(f"Error saving chat message: {e}")
        session.rollback()
    finally:
        session.close()

async def get_user_chat_history(
    discord_user_id: str,
    limit: int = 10,
    conversation_id: Optional[str] = None
) -> List[Dict[str, Any]]:
    """Get chat history for a specific user"""
    try:
        session = SessionLocal()
        query = session.query(ChatMessage).filter(
            ChatMessage.discord_user_id == discord_user_id
        )
        
        if conversation_id:
            query = query.filter(ChatMessage.conversation_id == conversation_id)
        
        messages = query.order_by(ChatMessage.timestamp.desc()).limit(limit).all()
        
        # Convert to list of dictionaries
        result = [
            {
                "role": message.role,
                "content": message.content,
                "timestamp": message.timestamp.isoformat()
            }
            for message in messages
        ]
        
        return result
    except SQLAlchemyError as e:
        logger.error(f"Error retrieving chat history: {e}")
        return []
    finally:
        session.close()

# User Profile Functions
async def get_or_create_user_profile(discord_user_id: str, discord_username: Optional[str] = None) -> Dict[str, Any]:
    """Get or create a user profile"""
    try:
        session = SessionLocal()
        
        # Try to find existing user profile
        user_profile = session.query(UserProfile).filter(
            UserProfile.discord_user_id == discord_user_id
        ).first()
        
        # Create a new profile if it doesn't exist
        if not user_profile:
            user_profile = UserProfile(
                discord_user_id=discord_user_id,
                discord_username=discord_username,
                opt_in_features=json.dumps({"notifications": False, "beta_features": False}),
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow()
            )
            session.add(user_profile)
            session.commit()
            logger.info(f"Created new user profile for Discord user {discord_user_id}")
        
        # Convert to dictionary
        result = {
            "discord_user_id": user_profile.discord_user_id,
            "discord_username": user_profile.discord_username,
            "preferred_language": user_profile.preferred_language,
            "preferred_model": user_profile.preferred_model,
            "opt_in_features": json.loads(user_profile.opt_in_features) if user_profile.opt_in_features else {},
            "is_premium": user_profile.is_premium,
            "premium_tier": user_profile.premium_tier,
            "created_at": user_profile.created_at.isoformat() if user_profile.created_at else None
        }
        
        return result
    except SQLAlchemyError as e:
        logger.error(f"Error getting/creating user profile: {e}")
        session.rollback()
        return {"discord_user_id": discord_user_id, "error": str(e)}
    finally:
        session.close()

async def update_user_preference(
    discord_user_id: str,
    preference_name: str,
    preference_value: Any
) -> bool:
    """Update a user preference"""
    try:
        session = SessionLocal()
        
        user_profile = session.query(UserProfile).filter(
            UserProfile.discord_user_id == discord_user_id
        ).first()
        
        if not user_profile:
            # Create a user profile if it doesn't exist
            user_profile = UserProfile(discord_user_id=discord_user_id)
            session.add(user_profile)
        
        # Update the appropriate preference
        if preference_name == "preferred_language":
            user_profile.preferred_language = preference_value
        elif preference_name == "preferred_model":
            user_profile.preferred_model = preference_value
        elif preference_name.startswith("opt_in_"):
            # Handle opt-in preferences
            feature_name = preference_name.replace("opt_in_", "")
            opt_in_features = json.loads(user_profile.opt_in_features) if user_profile.opt_in_features else {}
            opt_in_features[feature_name] = preference_value
            user_profile.opt_in_features = json.dumps(opt_in_features)
        else:
            # Fallback for other preferences
            setattr(user_profile, preference_name, preference_value)
        
        user_profile.updated_at = datetime.utcnow()
        session.commit()
        logger.info(f"Updated {preference_name} for user {discord_user_id} to {preference_value}")
        return True
    except SQLAlchemyError as e:
        logger.error(f"Error updating user preference: {e}")
        session.rollback()
        return False
    finally:
        session.close()

# Token Usage Tracking Functions
async def log_token_usage(
    model: str,
    prompt_tokens: int,
    completion_tokens: int
) -> None:
    """Log token usage for cost tracking"""
    try:
        total_tokens = prompt_tokens + completion_tokens
        
        # Calculate estimated cost based on model
        estimated_cost = 0.0
        if "gpt-4o" in model.lower():
            # GPT-4o pricing (approximate)
            estimated_cost = (prompt_tokens * 0.00001) + (completion_tokens * 0.00003)
        elif "gpt-3.5-turbo" in model.lower():
            # GPT-3.5 Turbo pricing (approximate)
            estimated_cost = (prompt_tokens * 0.000001) + (completion_tokens * 0.000002)
        elif "whisper" in model.lower():
            # Whisper pricing (approximate)
            estimated_cost = total_tokens * 0.00001
        
        session = SessionLocal()
        
        # Check if we already have an entry for this model today
        today = datetime.utcnow().date()
        token_usage = session.query(TokenUsage).filter(
            TokenUsage.model == model,
            TokenUsage.date >= today,
            TokenUsage.date < today + timedelta(days=1)
        ).first()
        
        if token_usage:
            # Update existing record
            token_usage.prompt_tokens += prompt_tokens
            token_usage.completion_tokens += completion_tokens
            token_usage.total_tokens += total_tokens
            token_usage.estimated_cost_usd += estimated_cost
        else:
            # Create new record
            token_usage = TokenUsage(
                date=datetime.utcnow(),
                model=model,
                prompt_tokens=prompt_tokens,
                completion_tokens=completion_tokens,
                total_tokens=total_tokens,
                estimated_cost_usd=estimated_cost
            )
            session.add(token_usage)
        
        session.commit()
    except SQLAlchemyError as e:
        logger.error(f"Error logging token usage: {e}")
        session.rollback()
    finally:
        session.close()

# Reminder Functions
async def create_reminder(
    discord_user_id: str,
    content: str,
    remind_at: datetime
) -> int:
    """Create a new reminder"""
    try:
        session = SessionLocal()
        
        reminder = Reminder(
            discord_user_id=discord_user_id,
            content=content,
            set_at=datetime.utcnow(),
            remind_at=remind_at,
            completed=False
        )
        
        session.add(reminder)
        session.commit()
        session.refresh(reminder)
        
        return reminder.id
    except SQLAlchemyError as e:
        logger.error(f"Error creating reminder: {e}")
        session.rollback()
        return -1
    finally:
        session.close()

async def get_due_reminders() -> List[Dict[str, Any]]:
    """Get all reminders that are due"""
    try:
        session = SessionLocal()
        
        reminders = session.query(Reminder).filter(
            Reminder.completed == False,
            Reminder.remind_at <= datetime.utcnow()
        ).all()
        
        result = [
            {
                "id": reminder.id,
                "discord_user_id": reminder.discord_user_id,
                "content": reminder.content,
                "set_at": reminder.set_at.isoformat(),
                "remind_at": reminder.remind_at.isoformat()
            }
            for reminder in reminders
        ]
        
        return result
    except SQLAlchemyError as e:
        logger.error(f"Error getting due reminders: {e}")
        return []
    finally:
        session.close()

async def mark_reminder_complete(reminder_id: int) -> bool:
    """Mark a reminder as completed"""
    try:
        session = SessionLocal()
        
        reminder = session.query(Reminder).filter(Reminder.id == reminder_id).first()
        if reminder:
            reminder.completed = True
            session.commit()
            return True
        return False
    except SQLAlchemyError as e:
        logger.error(f"Error marking reminder complete: {e}")
        session.rollback()
        return False
    finally:
        session.close()
