#!/bin/bash

# Load environment variables
source .env

echo "Creating tables in Supabase using service role key..."

# Create discord_users table
SQL_QUERY="CREATE TABLE IF NOT EXISTS discord_users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    discord_id TEXT NOT NULL UNIQUE,
    username TEXT,
    premium BOOLEAN DEFAULT FALSE,
    premium_tier INTEGER DEFAULT 0,
    preferences JSONB DEFAULT '{\"preferred_language\": \"en\", \"preferred_model\": \"gpt-3.5-turbo-0125\"}',
    opt_in_features JSONB DEFAULT '{\"notifications\": false, \"beta_features\": false}',
    tebex_customer_id TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

CREATE TABLE IF NOT EXISTS token_usage (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    discord_id TEXT NOT NULL,
    command TEXT,
    model TEXT,
    tokens INTEGER,
    estimated_cost FLOAT,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT now()
);

CREATE EXTENSION IF NOT EXISTS \"uuid-ossp\";"

# Create SQL file first
echo "$SQL_QUERY" > create_tables.sql

# Use curl to create tables using service role key
curl -X POST \
  "${SUPABASE_URL}/rest/v1/rpc/sql" \
  -H "apikey: ${SUPABASE_SERVICE_ROLE_KEY}" \
  -H "Authorization: Bearer ${SUPABASE_SERVICE_ROLE_KEY}" \
  -H "Content-Type: application/json" \
  -d "{\"query\": \"$SQL_QUERY\"}"

# Try alternative endpoint if the first one fails
curl -X POST \
  "${SUPABASE_URL}/rest/v1/rpc/execute" \
  -H "apikey: ${SUPABASE_SERVICE_ROLE_KEY}" \
  -H "Authorization: Bearer ${SUPABASE_SERVICE_ROLE_KEY}" \
  -H "Content-Type: application/json" \
  -d "{\"sql\": \"$SQL_QUERY\"}"

# Test if discord_users table exists
echo -e "\nChecking if tables were created successfully..."
curl -X GET \
  "${SUPABASE_URL}/rest/v1/discord_users?limit=1" \
  -H "apikey: ${SUPABASE_KEY}" \
  -H "Authorization: Bearer ${SUPABASE_KEY}"

# Test if token_usage table exists
echo -e "\nChecking token_usage table..."
curl -X GET \
  "${SUPABASE_URL}/rest/v1/token_usage?limit=1" \
  -H "apikey: ${SUPABASE_KEY}" \
  -H "Authorization: Bearer ${SUPABASE_KEY}"