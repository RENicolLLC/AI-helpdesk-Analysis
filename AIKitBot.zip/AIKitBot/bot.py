import os
import logging
import discord
from discord.ext import commands
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Get the bot token from environment variables
TOKEN = os.getenv("DISCORD_BOT_TOKEN")
if not TOKEN:
    raise ValueError("DISCORD_BOT_TOKEN not found in environment variables")

logger = logging.getLogger("bot")

# Set up intents for the bot
intents = discord.Intents.default()
intents.message_content = True
intents.members = True

# Initialize the bot with slash commands
bot = commands.Bot(command_prefix="!", intents=intents)

@bot.event
async def on_ready():
    """Event handler for when the bot is ready and connected to Discord."""
    logger.info(f"Bot is ready! Logged in as {bot.user} (ID: {bot.user.id})")
    
    # Sync slash commands
    try:
        synced = await bot.tree.sync()
        logger.info(f"Synced {len(synced)} command(s)")
    except Exception as e:
        logger.error(f"Failed to sync commands: {e}")
    
    await bot.change_presence(activity=discord.Activity(
        type=discord.ActivityType.listening, 
        name="AI Chat | /help"
    ))

@bot.event
async def on_command_error(ctx, error):
    """Global error handler for traditional commands."""
    if isinstance(error, commands.CommandNotFound):
        return
    
    logger.error(f"Command error: {error}")
    await ctx.send(f"Error: {error}")

@bot.tree.error
async def on_app_command_error(interaction, error):
    """Global error handler for slash commands."""
    logger.error(f"Slash command error: {error}")
    
    if interaction.response.is_done():
        await interaction.followup.send(f"Error: {str(error)}", ephemeral=True)
    else:
        await interaction.response.send_message(f"Error: {str(error)}", ephemeral=True)

async def load_extensions():
    """Load all cog extensions for the bot."""
    cogs = [
        "cogs.ai_chat",
        "cogs.voice",
        "cogs.translation",
        "cogs.web_context"
    ]
    
    for cog in cogs:
        try:
            await bot.load_extension(cog)
            logger.info(f"Loaded extension: {cog}")
        except Exception as e:
            logger.error(f"Failed to load extension {cog}: {e}")

def run_bot():
    """Run the Discord bot."""
    @bot.event
    async def setup_hook():
        """Setup hook that runs before the bot connects to Discord."""
        await load_extensions()
        logger.info("Setup complete")
    
    bot.setup_hook = setup_hook
    
    # Run the bot
    bot.run(TOKEN, log_handler=None)  # Disable discord.py's built-in logging

if __name__ == "__main__":
    run_bot()
