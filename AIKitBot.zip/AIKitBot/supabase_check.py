# supabase_check.py

import os
import requests
import logging
from dotenv import load_dotenv

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Load environment variables
load_dotenv()

SUPABASE_URL = os.environ.get("SUPABASE_URL")
SUPABASE_KEY = os.environ.get("SUPABASE_KEY")
SUPABASE_SERVICE_ROLE_KEY = os.environ.get("SUPABASE_SERVICE_ROLE_KEY")

HEADERS = {
    "apikey": SUPABASE_SERVICE_ROLE_KEY or SUPABASE_KEY,
    "Authorization": f"Bearer {SUPABASE_SERVICE_ROLE_KEY or SUPABASE_KEY}",
    "Content-Type": "application/json"
}

def check_supabase_status():
    """Check if we can connect to Supabase with our service role key"""
    url = f"{SUPABASE_URL}/rest/v1/"
    response = requests.get(url, headers=HEADERS)
    if response.status_code == 200:
        logger.info("✅ Supabase is connected and RLS is bypassed via service key.")
        return True
    else:
        logger.error(f"❌ Supabase connection issue: {response.status_code} - {response.text}")
        return False

def create_tables():
    """Create the necessary tables in Supabase"""
    logger.info("Creating tables in Supabase...")
    
    # SQL query to create tables
    sql_query = """
    CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
    
    CREATE TABLE IF NOT EXISTS discord_users (
        id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        discord_id TEXT NOT NULL UNIQUE,
        username TEXT,
        premium BOOLEAN DEFAULT FALSE,
        premium_tier INTEGER DEFAULT 0,
        preferences JSONB DEFAULT '{"preferred_language": "en", "preferred_model": "gpt-3.5-turbo-0125"}',
        opt_in_features JSONB DEFAULT '{"notifications": false, "beta_features": false}',
        tebex_customer_id TEXT,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
    );
    
    CREATE TABLE IF NOT EXISTS token_usage (
        id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        discord_id TEXT NOT NULL,
        command TEXT,
        model TEXT,
        tokens INTEGER,
        estimated_cost FLOAT,
        timestamp TIMESTAMP WITH TIME ZONE DEFAULT now()
    );
    
    CREATE TABLE IF NOT EXISTS reminders (
        id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        discord_id TEXT NOT NULL,
        reminder_text TEXT NOT NULL,
        remind_at TIMESTAMP WITH TIME ZONE NOT NULL,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
        completed BOOLEAN DEFAULT FALSE
    );
    """
    
    # Try various Supabase SQL endpoints
    endpoints = [
        {"url": f"{SUPABASE_URL}/rest/v1/rpc/sql", "key": "query"},
        {"url": f"{SUPABASE_URL}/rest/v1/rpc/execute_sql", "key": "query"},
        {"url": f"{SUPABASE_URL}/rest/v1/rpc/execute", "key": "sql"}
    ]
    
    for endpoint in endpoints:
        try:
            url = endpoint["url"]
            data_key = endpoint["key"]
            data = {data_key: sql_query}
            
            logger.info(f"Trying endpoint: {url}")
            response = requests.post(url, json=data, headers=HEADERS)
            
            if response.status_code < 400:
                logger.info(f"✅ Tables created successfully with endpoint {url}")
                return True
            else:
                logger.warning(f"❌ Failed to create tables with endpoint {url}: {response.status_code} - {response.text}")
        except Exception as e:
            logger.error(f"Error with endpoint {url}: {e}")
    
    logger.error("Failed to create tables using all available endpoints. Please create them manually.")
    logger.info("SQL to run manually:\n" + sql_query)
    return False

def test_insert_and_query():
    """Test inserting and querying data in Supabase"""
    # Test inserting a user profile
    user_url = f"{SUPABASE_URL}/rest/v1/discord_users"
    user_data = {
        "discord_id": "123456789012345678",
        "username": "test_user",
        "premium": False,
        "premium_tier": 0
    }
    
    logger.info("Testing user profile insertion...")
    user_response = requests.post(user_url, json=user_data, headers=HEADERS)
    if user_response.status_code == 201:
        logger.info("✅ Successfully inserted a test user")
    else:
        logger.warning(f"Failed to insert test user: {user_response.status_code} - {user_response.text}")
    
    # Test querying the user
    logger.info("Testing user profile retrieval...")
    query_params = {"discord_id": "eq.123456789012345678"}
    query_response = requests.get(user_url, headers=HEADERS, params=query_params)
    
    if query_response.status_code == 200:
        users = query_response.json()
        if users:
            logger.info(f"✅ Successfully retrieved test user: {users}")
        else:
            logger.warning("User was not found in the database")
    else:
        logger.warning(f"Failed to query test user: {query_response.status_code} - {query_response.text}")
    
    # Test inserting a reminder
    reminder_url = f"{SUPABASE_URL}/rest/v1/reminders"
    reminder_data = {
        "discord_id": "123456789012345678",
        "reminder_text": "This is a test reminder",
        "remind_at": "2025-05-10T12:00:00Z"
    }
    
    logger.info("Testing reminder insertion...")
    reminder_response = requests.post(reminder_url, json=reminder_data, headers=HEADERS)
    if reminder_response.status_code == 201:
        logger.info("✅ Successfully inserted a test reminder")
    else:
        logger.warning(f"Failed to insert test reminder: {reminder_response.status_code} - {reminder_response.text}")

def main():
    """Main function to test Supabase connection and functionality"""
    logger.info("=== SUPABASE SETUP AND TEST ===")
    
    # Check connection first
    if not check_supabase_status():
        logger.error("Cannot connect to Supabase. Check your credentials.")
        return
    
    # Try to create tables
    tables_created = create_tables()
    
    # If tables might be created, test inserting and querying data
    test_insert_and_query()
    
    logger.info("=== SUPABASE TEST COMPLETE ===")

if __name__ == "__main__":
    main()