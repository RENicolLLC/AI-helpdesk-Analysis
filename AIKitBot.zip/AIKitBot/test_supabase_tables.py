import os
import logging
import json
from dotenv import load_dotenv
from supabase import create_client

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Load environment variables
load_dotenv()

# Get Supabase credentials
SUPABASE_URL = os.environ.get("SUPABASE_URL")
SUPABASE_KEY = os.environ.get("SUPABASE_KEY")

def main():
    if not SUPABASE_URL or not SUPABASE_KEY:
        logger.error("Supabase credentials not found in environment variables")
        return
    
    logger.info(f"Testing connection to Supabase: {SUPABASE_URL}")
    
    try:
        # Initialize Supabase client
        supabase = create_client(SUPABASE_URL, SUPABASE_KEY)
        logger.info("✅ Supabase client initialized successfully")
        
        # Test discord_users table
        try:
            response = supabase.table("discord_users").select("*").limit(1).execute()
            logger.info(f"✅ discord_users table exists with {len(response.data)} records")
            
            # If no records, try to insert a test record
            if len(response.data) == 0:
                logger.info("No records found, inserting a test user")
                test_user = {
                    "discord_id": "test_user_999",
                    "username": "TestUser",
                    "premium": False,
                    "premium_tier": 0,
                    "preferences": json.dumps({
                        "preferred_language": "en",
                        "preferred_model": "gpt-3.5-turbo-0125"
                    }),
                    "opt_in_features": json.dumps({
                        "notifications": False,
                        "beta_features": False
                    })
                }
                
                insert_response = supabase.table("discord_users").insert(test_user).execute()
                if insert_response.data:
                    logger.info("✅ Test user inserted successfully")
                else:
                    logger.error("❌ Failed to insert test user")
        except Exception as e:
            logger.error(f"❌ Error with discord_users table: {e}")
        
        # Test token_usage table
        try:
            response = supabase.table("token_usage").select("*").limit(1).execute()
            logger.info(f"✅ token_usage table exists with {len(response.data)} records")
            
            # If no records, try to insert a test record
            if len(response.data) == 0:
                logger.info("No records found, inserting a test token usage record")
                test_usage = {
                    "discord_id": "test_user_999",
                    "command": "ask",
                    "model": "gpt-3.5-turbo-0125",
                    "tokens": 100,
                    "estimated_cost": 0.0002
                }
                
                insert_response = supabase.table("token_usage").insert(test_usage).execute()
                if insert_response.data:
                    logger.info("✅ Test token usage record inserted successfully")
                else:
                    logger.error("❌ Failed to insert test token usage record")
        except Exception as e:
            logger.error(f"❌ Error with token_usage table: {e}")
        
        logger.info("Supabase test complete")
        
    except Exception as e:
        logger.error(f"❌ Error connecting to Supabase: {e}")

if __name__ == "__main__":
    main()