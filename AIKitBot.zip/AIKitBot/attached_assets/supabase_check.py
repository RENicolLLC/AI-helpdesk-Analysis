
# supabase_check.py

import os
import requests

SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_KEY")

HEADERS = {
    "apikey": SUPABASE_KEY,
    "Authorization": f"Bearer {SUPABASE_KEY}",
    "Content-Type": "application/json"
}

def check_supabase_status():
    url = f"{SUPABASE_URL}/rest/v1/users"
    response = requests.get(url, headers=HEADERS)
    if response.status_code == 200:
        print("✅ Supabase is connected and RLS is bypassed via service key.")
    else:
        print("❌ Supabase connection issue:", response.status_code, response.text)

def test_insert_reminder():
    url = f"{SUPABASE_URL}/rest/v1/reminders"
    data = {
        "discord_id": "1234567890",
        "reminder_text": "RLS test reminder",
        "remind_at": "2025-05-07T12:00:00"
    }
    response = requests.post(url, json=data, headers=HEADERS)
    print("Insert:", response.status_code, response.json())

def test_read_reminders():
    url = f"{SUPABASE_URL}/rest/v1/reminders"
    params = {"discord_id": "eq.1234567890"}
    response = requests.get(url, headers=HEADERS, params=params)
    print("Read:", response.status_code, response.json())

if __name__ == "__main__":
    print("=== SUPABASE RLS CHECK ===")
    check_supabase_status()
    test_insert_reminder()
    test_read_reminders()
