import discord
import openai
import os
import time
import asyncio
import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any

from dotenv import load_dotenv
from flask import Flask, render_template, jsonify, request
import threading
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
)

# Load environment variables
load_dotenv()

# Get environment variables
TOKEN = os.getenv("DISCORD_BOT_TOKEN")
openai.api_key = os.getenv("OPENAI_API_KEY")
SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_KEY")

# Import database modules
from utils.db_manager import init_db, log_command_usage, get_or_create_user_profile, log_token_usage, save_chat_message
from utils.supabase_rest import init_supabase, supabase_initialized

# Initialize database connections
init_db()  # Initialize PostgreSQL database
supabase_connected = supabase_initialized  # Get Supabase connection status from the new REST-based module

# Create Flask app
app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

# Variable to track API status
discord_connected = False
openai_connected = openai.api_key is not None
discord_auth_error = None

@app.route('/status')
def status():
    # Update OpenAI connection status
    global openai_connected, discord_connected, supabase_connected
    openai_connected = openai.api_key is not None
    
    # Log current status for debugging
    logging.info(f"Status check - Discord connected: {discord_connected}, OpenAI connected: {openai_connected}")
    
    status_data = {
        'status': 'online',
        'discord_api': discord_connected,
        'openai_api': openai_connected,
        'replit_db': True,  # PostgreSQL is set up through Replit
        'supabase': supabase_connected
    }
    
    # Add Discord error message if there was an authentication issue
    if not discord_connected and discord_auth_error:
        status_data['discord_error'] = discord_auth_error
        
    return jsonify(status_data)

# Setup Discord client
# Create intents without requiring the privileged message_content intent
intents = discord.Intents.default()
intents.guilds = True  # For slash commands
intents.messages = True  # For message events
# Note: we've removed message_content intent which is privileged and requires special approval

class MyClient(discord.Client):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.tree = discord.app_commands.CommandTree(self)
        
    async def setup_hook(self):
        # Manually load user settings cog commands
        try:
            # Import and setup user settings cog
            from cogs.user_settings import UserSettings
            user_settings_cog = UserSettings(self)
            
            # Manually add each command from user settings
            self.tree.add_command(user_settings_cog.settings)
            self.tree.add_command(user_settings_cog.profile)
            self.tree.add_command(user_settings_cog.remindme)
            logging.info("Loaded user settings cog commands")
        except Exception as e:
            logging.error(f"Failed to load cogs: {e}")
        
        # Start reminder task
        from utils.reminder_manager import start_reminder_task
        start_reminder_task(self)
        
        # Sync commands with Discord
        await self.tree.sync()
        logging.info("Command tree synced")

client = MyClient(intents=intents)

@client.event
async def on_ready():
    global discord_connected
    discord_connected = True
    logging.info(f'✅ Bot is live as {client.user}')
    await client.change_presence(activity=discord.Activity(type=discord.ActivityType.listening, name="AI Chat | /help"))

@client.event
async def on_message(message):
    # Skip messages from the bot itself
    if message.author.bot:
        return
    
    # Check if the message is in the ai-chat channel
    if hasattr(message.channel, 'name') and message.channel.name == "ai-chat":
        logging.info(f"Received message in AI chat from {message.author}: {message.content}")
        
        try:
            async with message.channel.typing():
                # Generate a response using OpenAI (using cost-effective model for AI chat)
                response = openai.chat.completions.create(
                    model="gpt-3.5-turbo-0125",
                    messages=[{"role": "user", "content": message.content}]
                )
                reply = response.choices[0].message.content
                
                # Create an embed for the response
                embed = discord.Embed(
                    title="AI Response",
                    description=reply,
                    color=discord.Color.blue(),
                    timestamp=discord.utils.utcnow()
                )
                embed.set_footer(text=f"Responding to {message.author.display_name}")
                
                # Log token usage
                prompt_tokens = response.usage.prompt_tokens
                completion_tokens = response.usage.completion_tokens
                
                # Save conversation context and log usage in background
                user_id = str(message.author.id)
                conversation_id = f"channel_{message.channel.id}_{int(time.time())}"
                
                # Log command usage in background
                asyncio.create_task(log_command_usage(
                    command_name="ai_chat",
                    discord_user_id=user_id,
                    server_id=str(message.guild.id) if message.guild else None,
                    channel_id=str(message.channel.id),
                    model_used="gpt-3.5-turbo-0125",
                    tokens_used=prompt_tokens + completion_tokens
                ))
                
                # Log token usage in background
                asyncio.create_task(log_token_usage(
                    model="gpt-3.5-turbo-0125",
                    prompt_tokens=prompt_tokens,
                    completion_tokens=completion_tokens
                ))
                
                # Save the conversation for context in background
                asyncio.create_task(save_chat_message(
                    discord_user_id=user_id,
                    role="user",
                    content=message.content,
                    conversation_id=conversation_id,
                    model_used="gpt-3.5-turbo-0125"
                ))
                
                asyncio.create_task(save_chat_message(
                    discord_user_id=user_id,
                    role="assistant",
                    content=reply,
                    conversation_id=conversation_id,
                    model_used="gpt-3.5-turbo-0125"
                ))
                
                await message.reply(embed=embed)
                logging.info(f"Sent AI response to {message.author}")
        except Exception as e:
            logging.error(f"Error generating AI response: {e}")
            await message.reply(f"Sorry, I couldn't process your request: {str(e)}")
    
    # For other channels, do nothing
    return

# @client.tree.command(name="ask", description="Ask the AI assistant a question")
# This command is now handled by the AIChat cog
# def ask_command(): pass

# @client.tree.command(name="translate", description="Translate text to another language")
# This command is now handled by the Translation cog

# @client.tree.command(name="web_search", description="Get information from a website")
# This command is now handled by the WebContext cog

# @client.tree.command(name="transcribe", description="Transcribe an audio file")
# This command is now handled by the Voice cog

# @client.tree.command(name="help", description="Get help with using the AI assistant")
# This command is now handled by the AIChat cog

# Function to run Discord bot
def run_discord_bot():
    global discord_connected, discord_auth_error
    try:
        discord_connected = False  # Reset the status at startup
        discord_auth_error = None  # Clear any previous errors
        client.run(TOKEN)
    except discord.errors.LoginFailure as e:
        error_msg = f"Discord authentication failed: {e}"
        logging.error(error_msg)
        discord_connected = False
        discord_auth_error = error_msg
    except discord.errors.PrivilegedIntentsRequired as e:
        error_msg = f"Privileged intents not enabled: {e}. Please enable MESSAGE CONTENT intent in the Discord Developer Portal."
        logging.error(error_msg)
        discord_connected = False
        discord_auth_error = error_msg
    except Exception as e:
        error_msg = f"Error starting Discord bot: {e}"
        logging.error(error_msg)
        discord_connected = False
        discord_auth_error = error_msg

# Start the bot in a separate thread when running under Gunicorn
if 'gunicorn' in os.environ.get('SERVER_SOFTWARE', ''):
    bot_thread = threading.Thread(target=run_discord_bot)
    bot_thread.daemon = True
    bot_thread.start()
    logging.info("Started Discord bot in a background thread")

if __name__ == "__main__":
    # Run the Discord bot directly when running as script
    run_discord_bot()
