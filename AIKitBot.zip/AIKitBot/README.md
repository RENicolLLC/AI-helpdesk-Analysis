# AIkitsBot - Intelligent Discord Bot

<p align="center">
  <img src="generated-icon.png" alt="AIkitsBot Logo" width="200"/>
</p>

## Overview

AIkitsBot is an advanced Discord bot powered by OpenAI, offering intelligent and interactive communication capabilities through sophisticated AI integration. It provides a suite of features from AI chat to web search, translation, and audio transcription.

## Core Features

### AI Chat
- **Command**: `/ask`
- **Description**: Interact with the AI by asking questions or having conversations
- **Options**: 
  - `question`: The text to send to the AI (required)
  - `complexity`: Low, medium, or high (determines which AI model is used)
  - `ephemeral`: Whether the response should only be visible to you
- **Model Selection**: Automatically selects between gpt-3.5-turbo-0125 (default) and GPT-4o (for high complexity) based on the complexity parameter

### Custom AI Templates
- **Command**: `/custom`
- **Description**: Get AI responses using specialized templates
- **Options**:
  - `prompt`: Your input text (required)
  - `template`: The template to use (code_assistant, writing_tutor, creative_storyteller, debate_coach, research_analyst)
  - `ephemeral`: Whether the response should only be visible to you

### Translation
- **Command**: `/translate`
- **Description**: Translate text to different languages using AI
- **Options**:
  - `text`: The text to translate (required)
  - `target_language`: The language to translate to (required)
  - `ephemeral`: Whether the response should only be visible to you

### Web Search
- **Command**: `/web_search`
- **Description**: Get information from websites or ask questions about their content
- **Options**:
  - `url`: The URL of the website to search (required)
  - `query`: Optional question about the website content
  - `ephemeral`: Whether the response should only be visible to you

### Audio Transcription
- **Command**: `/transcribe`
- **Description**: Transcribe audio files using OpenAI's Whisper model
- **Options**:
  - `audio_file`: The audio file to transcribe (required)
  - `ephemeral`: Whether the response should only be visible to you

### User Settings
- **Command**: `/settings`
- **Description**: View or update your user preferences
- **Options**:
  - `setting`: The setting to change (optional)
  - `value`: The new value for the setting (optional)

### User Profile
- **Command**: `/profile`
- **Description**: View your user profile and usage statistics

### Reminders
- **Command**: `/remindme`
- **Description**: Set reminders for yourself
- **Options**:
  - `message`: The reminder message (required)
  - `when`: When to be reminded (required, e.g., "in 2 hours", "tomorrow at 3pm")

## AI Channel

The bot also responds to messages in a channel named "ai-chat" without requiring a slash command prefix. Just type your message in this channel and get AI responses.

## Technical Features

- **Intelligent Model Selection**: Uses cost-effective models for routine tasks (gpt-3.5-turbo-0125) and more capable models for complex queries (GPT-4o)
- **Database Integration**: PostgreSQL database for tracking command usage, storing user preferences, and AI conversation history
- **Premium User Support**: Infrastructure for premium user tiers with special features
- **Context Memory**: Maintains context between questions for more coherent conversations
- **Comprehensive Error Handling**: Robust error management for reliable operation
- **Modular Design**: Organized in a cog system for easy maintenance and expansion

## Setup and Configuration

### Prerequisites

- Python 3.11 or higher
- PostgreSQL database
- Discord Bot Token
- OpenAI API Key

### Environment Variables

Create a `.env` file with the following variables:

```
# Discord Bot Token
DISCORD_BOT_TOKEN=your_discord_bot_token

# OpenAI API Key
OPENAI_API_KEY=your_openai_api_key

# Database Connection (provided by Replit or set your own)
DATABASE_URL=postgresql://username:password@host:port/database
PGHOST=host
PGPORT=port
PGUSER=username
PGPASSWORD=password
PGDATABASE=database

# Optional: Supabase for premium features
SUPABASE_URL=your_supabase_url
SUPABASE_KEY=your_supabase_key
```

### Installation

1. Clone the repository
2. Install dependencies: `pip install -r requirements.txt` or use the provided `pyproject.toml`
3. Set up environment variables
4. Run the bot: `python bot.py` or use the Replit workflow

## Project Structure

```
/
├── bot.py                # Discord bot initialization
├── main.py               # Flask web interface
├── wsgi.py               # WSGI entry point
├── pyproject.toml        # Python dependencies
├── .env                  # Environment variables (not committed)
├── .env.example          # Example environment variables
├── generated-icon.png    # Bot logo
│
├── cogs/                 # Discord bot command modules
│   ├── ai_chat.py        # AI chat commands
│   ├── translation.py    # Translation commands
│   ├── user_settings.py  # User settings management
│   ├── voice.py          # Audio transcription
│   └── web_context.py    # Web search and content extraction
│
├── models/               # Database models
│   └── database.py       # SQLAlchemy database models
│
├── utils/                # Utility functions
│   ├── command_utils.py  # Command decorators and utilities
│   ├── db_manager.py     # Database operations
│   ├── embed_helper.py   # Discord embed formatting
│   ├── openai_helper.py  # OpenAI API integration
│   ├── reminder_manager.py # Reminder system
│   ├── supabase_manager.py # Supabase integration
│   └── web_scraper.py    # Web content extraction
│
├── static/               # Static files for web interface
└── templates/            # HTML templates for web interface
    └── index.html        # Main dashboard
```

## Version History

### v1.0.0 (2025-05-06)
- Initial release with core AI chat functionality
- Added translation, web search, and audio transcription
- Implemented user settings and profile management
- Added reminder system
- Created database integration for tracking usage and storing preferences

## License

© 2025 All Rights Reserved

## Credits

- **Discord.py**: The foundation for bot functionality
- **OpenAI**: Providing the AI models that power responses
- **Trafilatura**: Web content extraction
- **SQLAlchemy**: Database ORM
- **Flask**: Web interface

---

*AIkitsBot is running on Replit infrastructure for 24/7 availability.*