import os
import logging
import discord
from discord import app_commands
from discord.ext import commands
from typing import Optional, Literal

from utils.openai_helper import generate_chat_response, get_openai_models
from utils.embed_helper import create_response_embed

logger = logging.getLogger("bot.ai_chat")

class AIChat(commands.Cog):
    """Cog for handling AI chat functionality using OpenAI's API."""
    
    def __init__(self, bot):
        self.bot = bot
        self.ai_channel_name = "ai-chat"  # Default channel name for AI chat
    
    @commands.Cog.listener()
    async def on_message(self, message):
        """Listen for messages in the ai-chat channel and respond with AI."""
        # Skip messages from bots (including self)
        if message.author.bot:
            return
        
        # Check if the message is in the designated AI chat channel
        if message.channel.name.lower() == self.ai_channel_name.lower():
            async with message.channel.typing():
                logger.info(f"Received message in AI chat from {message.author}: {message.content}")
                
                try:
                    # Generate a response using OpenAI
                    response = await generate_chat_response(message.content)
                    
                    # Create an embed for the response
                    embed = create_response_embed(
                        title="AI Response",
                        description=response,
                        user=message.author
                    )
                    
                    await message.reply(embed=embed)
                    logger.info(f"Sent AI response to {message.author}")
                except Exception as e:
                    logger.error(f"Error generating AI response: {e}")
                    await message.reply(f"Sorry, I couldn't generate a response: {str(e)}")
    
    @app_commands.command(name="ask", description="Ask the AI assistant a question")
    @app_commands.describe(
        question="Your question or prompt for the AI",
        model="Choose the AI model to use (default: gpt-3.5-turbo-0125)",
        ephemeral="Whether the response should be visible only to you"
    )
    async def ask(
        self, 
        interaction: discord.Interaction, 
        question: str, 
        model: Optional[str] = "gpt-3.5-turbo-0125",
        ephemeral: Optional[bool] = False
    ):
        """Slash command to ask the AI a question."""
        await interaction.response.defer(ephemeral=ephemeral)
        
        try:
            logger.info(f"Processing /ask command from {interaction.user}: {question}")
            
            # Generate a response using OpenAI
            response = await generate_chat_response(question, model=model)
            
            # Create an embed for the response
            embed = create_response_embed(
                title="AI Response",
                description=response,
                user=interaction.user,
                footer=f"Model: {model}"
            )
            
            await interaction.followup.send(embed=embed, ephemeral=ephemeral)
            logger.info(f"Sent AI response to {interaction.user}")
        except Exception as e:
            logger.error(f"Error in /ask command: {e}")
            await interaction.followup.send(f"Error: {str(e)}", ephemeral=True)
    
    @app_commands.command(name="custom", description="Get a custom AI response based on a specific role or template")
    @app_commands.describe(
        prompt="Your question or prompt for the AI",
        template="The template or role for the AI to use",
        ephemeral="Whether the response should be visible only to you"
    )
    async def custom(
        self,
        interaction: discord.Interaction,
        prompt: str,
        template: Literal["code_assistant", "writing_tutor", "creative_storyteller", "debate_coach", "research_analyst"],
        ephemeral: Optional[bool] = False
    ):
        """Slash command to get a custom AI response with a specific template."""
        await interaction.response.defer(ephemeral=ephemeral)
        
        templates = {
            "code_assistant": "You are an expert programming assistant. Provide clean, efficient code solutions with explanations. Focus on best practices and readability.",
            "writing_tutor": "You are a writing tutor helping to improve writing skills. Provide constructive feedback, suggest improvements, and explain writing principles.",
            "creative_storyteller": "You are a creative storyteller. Create engaging, imaginative stories or continue the narrative provided by the user.",
            "debate_coach": "You are a debate coach. Present balanced arguments for both sides of an issue, highlight logical strengths and weaknesses, and provide evidence-based reasoning.",
            "research_analyst": "You are a research analyst. Synthesize information on a topic, provide balanced analysis, cite relevant sources when possible, and identify areas for further investigation."
        }
        
        system_prompt = templates.get(template)
        
        if not system_prompt:
            await interaction.followup.send("Invalid template selected.", ephemeral=True)
            return
        
        try:
            logger.info(f"Processing /custom command from {interaction.user} with template {template}: {prompt}")
            
            # For the custom templates, we'll use a higher complexity level for better responses
            # Determine if this is a code-related task
            task_type = "code" if template == "code_assistant" else "general"
            # Use medium complexity for all templates since they require more careful responses
            complexity = "medium" 
            
            # Generate a response using OpenAI with the selected template
            response = await generate_chat_response(
                prompt, 
                system_prompt=system_prompt,
                task_type=task_type,
                complexity=complexity
            )
            
            # Create an embed for the response
            embed = create_response_embed(
                title=f"{template.replace('_', ' ').title()} Response",
                description=response,
                user=interaction.user,
                footer="Template: " + template.replace('_', ' ').title()
            )
            
            await interaction.followup.send(embed=embed, ephemeral=ephemeral)
            logger.info(f"Sent custom AI response to {interaction.user}")
        except Exception as e:
            logger.error(f"Error in /custom command: {e}")
            await interaction.followup.send(f"Error: {str(e)}", ephemeral=True)
    
    @ask.autocomplete('model')
    async def model_autocomplete(self, interaction: discord.Interaction, current: str):
        """Autocomplete for model selection in the ask command."""
        models = get_openai_models()
        return [
            app_commands.Choice(name=model, value=model)
            for model in models if current.lower() in model.lower()
        ][:25]  # Discord limits to 25 choices

    @app_commands.command(name="help", description="Get help with using the AI assistant")
    async def help_command(self, interaction: discord.Interaction):
        """Display help information about the bot's features."""
        embed = discord.Embed(
            title="AI Assistant Help",
            description="Here's how to use the AI assistant:",
            color=discord.Color.blue()
        )
        
        embed.add_field(
            name="💬 AI Chat",
            value="Simply send messages in the #ai-chat channel to get AI responses.",
            inline=False
        )
        
        embed.add_field(
            name="/ask",
            value="Ask the AI a specific question with optional model selection.",
            inline=False
        )
        
        embed.add_field(
            name="/custom",
            value="Get responses with specific templates (code, writing, storytelling, debate, research).",
            inline=False
        )
        
        embed.add_field(
            name="/web_search",
            value="Search for information on the web and get AI analysis.",
            inline=False
        )
        
        embed.add_field(
            name="/transcribe",
            value="Transcribe an audio file using OpenAI Whisper.",
            inline=False
        )
        
        embed.add_field(
            name="/translate",
            value="Translate text to different languages using AI.",
            inline=False
        )
        
        await interaction.response.send_message(embed=embed, ephemeral=True)

async def setup(bot):
    """Setup function to add the cog to the bot."""
    await bot.add_cog(AIChat(bot))
