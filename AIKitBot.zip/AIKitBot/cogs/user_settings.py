import logging
import json
from typing import Optional, Dict, Any, List

import discord
from discord import app_commands
from discord.ext import commands

from utils.db_manager import get_or_create_user_profile, update_user_preference
from utils.supabase_manager import get_user_preference, set_user_preference, check_premium_status
from utils.command_utils import log_command, with_user_preferences

logger = logging.getLogger(__name__)

class UserSettings(commands.Cog):
    """Cog for managing user preferences and settings."""
    
    def __init__(self, bot):
        self.bot = bot
        
    @app_commands.command(name="settings", description="View or update your user settings")
    @app_commands.describe(
        setting="The setting to update (language, model)",
        value="The new value for the setting"
    )
    @log_command("settings")
    async def settings(self, interaction: discord.Interaction, setting: Optional[str] = None, value: Optional[str] = None):
        """View or update your settings."""
        await interaction.response.defer(ephemeral=True)
        
        try:
            user_id = str(interaction.user.id)
            
            # Get user profile
            user_profile = await get_or_create_user_profile(
                discord_user_id=user_id,
                discord_username=interaction.user.display_name
            )
            
            # Check premium status
            premium_status = await check_premium_status(user_id)
            is_premium = premium_status.get("is_premium", False)
            tier = premium_status.get("tier", 0)
            
            if setting and value:
                # Update a specific setting
                if setting.lower() == "language":
                    await update_user_preference(user_id, "preferred_language", value)
                    await set_user_preference(user_id, "preferred_language", value)  # Also update in Supabase if available
                    await interaction.followup.send(f"Your preferred language has been set to: {value}", ephemeral=True)
                    return
                    
                elif setting.lower() == "model":
                    valid_models = ["gpt-3.5-turbo-0125", "gpt-4o"]
                    
                    # Only premium users can set gpt-4o as default
                    if value == "gpt-4o" and not is_premium:
                        premium_embed = discord.Embed(
                            title="Premium Feature",
                            description="Setting GPT-4o as your default model is only available to premium users.",
                            color=discord.Color.gold()
                        )
                        await interaction.followup.send(embed=premium_embed, ephemeral=True)
                        return
                        
                    if value in valid_models:
                        await update_user_preference(user_id, "preferred_model", value)
                        await set_user_preference(user_id, "preferred_model", value)  # Also update in Supabase if available
                        await interaction.followup.send(f"Your preferred model has been set to: {value}", ephemeral=True)
                    else:
                        await interaction.followup.send(f"Invalid model. Valid options are: {', '.join(valid_models)}", ephemeral=True)
                    return
                    
                elif setting.lower().startswith("opt_in_"):
                    # Handle opt-in features
                    feature = setting.lower().replace("opt_in_", "")
                    bool_value = value.lower() in ["true", "yes", "on", "1"]
                    
                    # Some opt-in features might be premium-only
                    premium_features = ["beta_features"]
                    if feature in premium_features and bool_value and not is_premium:
                        premium_embed = discord.Embed(
                            title="Premium Feature",
                            description=f"The {feature} feature is only available to premium users.",
                            color=discord.Color.gold()
                        )
                        await interaction.followup.send(embed=premium_embed, ephemeral=True)
                        return
                    
                    await update_user_preference(user_id, f"opt_in_{feature}", bool_value)
                    await interaction.followup.send(f"Your preference for {feature} has been set to: {bool_value}", ephemeral=True)
                    return
                
                else:
                    await interaction.followup.send(f"Unknown setting: {setting}", ephemeral=True)
                    return
            
            # Display current settings
            embed = discord.Embed(
                title="Your Settings",
                description="Here are your current settings and preferences:",
                color=discord.Color.blue() if not is_premium else discord.Color.gold()
            )
            
            # Basic settings
            embed.add_field(
                name="Default Language",
                value=user_profile.get("preferred_language", "English (en)"),
                inline=True
            )
            
            embed.add_field(
                name="Default AI Model",
                value=user_profile.get("preferred_model", "gpt-3.5-turbo-0125"),
                inline=True
            )
            
            # Opt-in features
            opt_in_features = {}
            if "opt_in_features" in user_profile and user_profile["opt_in_features"]:
                try:
                    if isinstance(user_profile["opt_in_features"], str):
                        opt_in_features = json.loads(user_profile["opt_in_features"])
                    else:
                        opt_in_features = user_profile["opt_in_features"]
                except:
                    opt_in_features = {}
            
            opt_in_list = []
            for feature, enabled in opt_in_features.items():
                status = "✅ Enabled" if enabled else "❌ Disabled"
                opt_in_list.append(f"{feature}: {status}")
            
            embed.add_field(
                name="Feature Opt-ins",
                value="\n".join(opt_in_list) if opt_in_list else "No preferences set",
                inline=False
            )
            
            # Premium status
            premium_status_text = f"✅ Premium (Tier {tier})" if is_premium else "❌ Not Premium"
            embed.add_field(
                name="Premium Status",
                value=premium_status_text,
                inline=True
            )
            
            # Usage info
            embed.add_field(
                name="Commands to Change Settings",
                value="`/settings language <code>`: Set your preferred language\n"
                      "`/settings model <model>`: Set your preferred AI model\n"
                      "`/settings opt_in_notifications true/false`: Enable/disable notifications",
                inline=False
            )
            
            await interaction.followup.send(embed=embed, ephemeral=True)
            
        except Exception as e:
            logger.error(f"Error in /settings command: {e}")
            await interaction.followup.send(f"Error: {str(e)}", ephemeral=True)
    
    @app_commands.command(name="profile", description="View your user profile and usage statistics")
    @log_command("profile")
    async def profile(self, interaction: discord.Interaction):
        """View your user profile and usage statistics."""
        await interaction.response.defer(ephemeral=True)
        
        try:
            user_id = str(interaction.user.id)
            
            # Get user profile
            user_profile = await get_or_create_user_profile(
                discord_user_id=user_id,
                discord_username=interaction.user.display_name
            )
            
            # Check premium status
            premium_status = await check_premium_status(user_id)
            is_premium = premium_status.get("is_premium", False)
            tier = premium_status.get("tier", 0)
            
            embed = discord.Embed(
                title="Your Profile",
                description=f"User profile for {interaction.user.display_name}",
                color=discord.Color.blue() if not is_premium else discord.Color.gold()
            )
            
            # Set user avatar if available
            if interaction.user.avatar:
                embed.set_thumbnail(url=interaction.user.avatar.url)
            
            # Basic profile info
            embed.add_field(
                name="Discord Username",
                value=interaction.user.display_name,
                inline=True
            )
            
            embed.add_field(
                name="Account Created",
                value=user_profile.get("created_at", "Unknown"),
                inline=True
            )
            
            # Premium status
            premium_status_text = f"✅ Premium (Tier {tier})" if is_premium else "❌ Not Premium"
            embed.add_field(
                name="Premium Status",
                value=premium_status_text,
                inline=True
            )
            
            # TODO: Add usage statistics from the database (once we have some data)
            # This will be implemented later when we have sufficient usage data
            
            embed.set_footer(text="Use /settings to update your preferences")
            
            await interaction.followup.send(embed=embed, ephemeral=True)
        
        except Exception as e:
            logger.error(f"Error in /profile command: {e}")
            await interaction.followup.send(f"Error: {str(e)}", ephemeral=True)
    
    @app_commands.command(name="remindme", description="Set a reminder for yourself")
    @app_commands.describe(
        message="What to remind you about",
        when="When to remind you (e.g., '2h' for 2 hours, '30m' for 30 minutes, or '1d' for 1 day)"
    )
    @log_command("remindme")
    async def remindme(self, interaction: discord.Interaction, message: str, when: str):
        """Set a reminder for yourself."""
        from datetime import datetime, timedelta
        import re
        
        await interaction.response.defer(ephemeral=True)
        
        try:
            # Parse the time string
            time_pattern = re.compile(r'(\d+)([mhd])')
            match = time_pattern.match(when.lower())
            
            if not match:
                await interaction.followup.send(
                    "Invalid time format. Please use format like '2h' for 2 hours, '30m' for 30 minutes, or '1d' for 1 day.",
                    ephemeral=True
                )
                return
            
            amount, unit = match.groups()
            amount = int(amount)
            
            # Calculate reminder time
            now = datetime.utcnow()
            if unit == 'm':
                remind_at = now + timedelta(minutes=amount)
            elif unit == 'h':
                remind_at = now + timedelta(hours=amount)
            elif unit == 'd':
                remind_at = now + timedelta(days=amount)
            else:
                await interaction.followup.send("Invalid time unit. Use 'm' for minutes, 'h' for hours, or 'd' for days.", ephemeral=True)
                return
            
            # Create the reminder
            from utils.db_manager import create_reminder
            reminder_id = await create_reminder(
                discord_user_id=str(interaction.user.id),
                content=message,
                remind_at=remind_at
            )
            
            if reminder_id > 0:
                # Format the time for display
                from datetime import timezone
                time_format = "%Y-%m-%d %H:%M UTC"
                formatted_time = remind_at.replace(tzinfo=timezone.utc).strftime(time_format)
                
                embed = discord.Embed(
                    title="Reminder Set",
                    description=f"I'll remind you about: {message}",
                    color=discord.Color.green(),
                    timestamp=discord.utils.utcnow()
                )
                embed.add_field(name="When", value=formatted_time, inline=True)
                embed.add_field(name="Reminder ID", value=str(reminder_id), inline=True)
                
                await interaction.followup.send(embed=embed, ephemeral=True)
            else:
                await interaction.followup.send("Failed to create reminder. Please try again.", ephemeral=True)
        
        except Exception as e:
            logger.error(f"Error in /remindme command: {e}")
            await interaction.followup.send(f"Error: {str(e)}", ephemeral=True)

async def setup(bot):
    """Setup function to add the cog to the bot."""
    await bot.add_cog(UserSettings(bot))
