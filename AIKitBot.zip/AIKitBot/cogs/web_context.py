import logging
import discord
from discord import app_commands
from discord.ext import commands
from typing import Optional

from utils.web_scraper import get_website_text_content
from utils.openai_helper import generate_chat_response, summarize_website_content
from utils.embed_helper import create_response_embed

logger = logging.getLogger("bot.web_context")

class WebContext(commands.Cog):
    """Cog for handling web-related commands and providing external context."""
    
    def __init__(self, bot):
        self.bot = bot
    
    @app_commands.command(name="web_search", description="Search for information on the web")
    @app_commands.describe(
        url="The website URL to analyze",
        query="Optional query to ask about the website content",
        ephemeral="Whether the response should be visible only to you"
    )
    async def web_search(
        self,
        interaction: discord.Interaction,
        url: str,
        query: Optional[str] = None,
        ephemeral: Optional[bool] = False
    ):
        """Search for information on a website and optionally ask questions about it."""
        await interaction.response.defer(ephemeral=ephemeral)
        
        try:
            logger.info(f"Processing web search for {url} from {interaction.user}")
            
            # Extract text content from the website
            website_content = await get_website_text_content(url)
            
            if not website_content:
                await interaction.followup.send(
                    "Could not extract content from the provided URL. Please check the URL and try again.",
                    ephemeral=True
                )
                return
            
            # If a query is provided, answer it based on the website content
            if query:
                # Create a prompt that includes the website content and the user's query
                prompt = f"Based on the following website content, please answer this question: {query}\n\nWebsite Content:\n{website_content}"
                
                # For web content analysis with specific questions, we'll use higher complexity
                # This helps ensure better reasoning about the content
                complexity = "medium" if len(website_content) > 1000 else "low"
                
                # Generate a response using OpenAI
                response = await generate_chat_response(
                    prompt,
                    system_prompt="You are a helpful assistant that answers questions based on website content. Provide accurate information from the content provided.",
                    task_type="analysis",
                    complexity=complexity
                )
                
                # Create an embed for the response
                embed = create_response_embed(
                    title=f"Answer based on {url}",
                    description=response,
                    user=interaction.user
                )
                
                embed.add_field(name="Your Question", value=query, inline=False)
                embed.add_field(name="Source", value=url, inline=False)
                
                await interaction.followup.send(embed=embed, ephemeral=ephemeral)
                logger.info(f"Sent web search response to {interaction.user}")
            else:
                # If no query is provided, just summarize the website
                summary = await summarize_website_content(website_content)
                
                # Create an embed for the summary
                embed = create_response_embed(
                    title=f"Summary of {url}",
                    description=summary,
                    user=interaction.user
                )
                
                embed.add_field(name="Source", value=url, inline=False)
                
                await interaction.followup.send(embed=embed, ephemeral=ephemeral)
                logger.info(f"Sent website summary to {interaction.user}")
        except Exception as e:
            logger.error(f"Error in /web_search command: {e}")
            await interaction.followup.send(f"Error: {str(e)}", ephemeral=True)

async def setup(bot):
    """Setup function to add the cog to the bot."""
    await bot.add_cog(WebContext(bot))
