import logging
import discord
from discord import app_commands
from discord.ext import commands
from typing import Optional, List

from utils.openai_helper import translate_text
from utils.embed_helper import create_response_embed

logger = logging.getLogger("bot.translation")

class Translation(commands.Cog):
    """Cog for handling translation commands using OpenAI."""
    
    def __init__(self, bot):
        self.bot = bot
        self.languages = [
            "English", "Spanish", "French", "German", "Italian", "Portuguese", 
            "Dutch", "Russian", "Chinese", "Japanese", "Korean", "Arabic", 
            "Hindi", "Bengali", "Turkish", "Vietnamese", "Thai", "Indonesian",
            "Polish", "Swedish", "Norwegian", "Danish", "Finnish", "Greek",
            "Czech", "Romanian", "Hungarian", "Ukrainian", "Hebrew", "Swahili"
        ]
    
    @app_commands.command(name="translate", description="Translate text to a different language")
    @app_commands.describe(
        text="The text to translate",
        target_language="The language to translate to",
        ephemeral="Whether the response should be visible only to you"
    )
    async def translate(
        self,
        interaction: discord.Interaction,
        text: str,
        target_language: str,
        ephemeral: Optional[bool] = False
    ):
        """Translate text to a different language using OpenAI."""
        await interaction.response.defer(ephemeral=ephemeral)
        
        try:
            logger.info(f"Translating text to {target_language} for {interaction.user}")
            
            # Translate the text using OpenAI
            translated_text = await translate_text(text, target_language)
            
            # Create an embed for the response
            embed = create_response_embed(
                title=f"Translation to {target_language}",
                description=translated_text,
                user=interaction.user
            )
            
            # Add original text as a field
            embed.add_field(name="Original Text", value=text, inline=False)
            
            await interaction.followup.send(embed=embed, ephemeral=ephemeral)
            logger.info(f"Sent translation to {interaction.user}")
        except Exception as e:
            logger.error(f"Error in /translate command: {e}")
            await interaction.followup.send(f"Error: {str(e)}", ephemeral=True)
    
    @translate.autocomplete('target_language')
    async def language_autocomplete(self, interaction: discord.Interaction, current: str):
        """Autocomplete for language selection in the translate command."""
        return [
            app_commands.Choice(name=language, value=language)
            for language in self.languages if current.lower() in language.lower()
        ][:25]  # Discord limits to 25 choices

async def setup(bot):
    """Setup function to add the cog to the bot."""
    await bot.add_cog(Translation(bot))
