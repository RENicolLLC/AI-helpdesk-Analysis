import os
import logging
import tempfile
import discord
from discord import app_commands
from discord.ext import commands
import aiohttp
from io import BytesIO

from utils.openai_helper import transcribe_audio
from utils.embed_helper import create_response_embed

logger = logging.getLogger("bot.voice")

class Voice(commands.Cog):
    """Cog for handling voice-related commands using OpenAI's Whisper API."""
    
    def __init__(self, bot):
        self.bot = bot
    
    @app_commands.command(name="transcribe", description="Transcribe an audio file using OpenAI Whisper")
    @app_commands.describe(
        audio_file="The audio file to transcribe (mp3, mp4, mpeg, mpga, m4a, wav, or webm)",
        ephemeral="Whether the response should be visible only to you"
    )
    async def transcribe(
        self,
        interaction: discord.Interaction,
        audio_file: discord.Attachment,
        ephemeral: bool = False
    ):
        """Transcribe an audio file using OpenAI's Whisper API."""
        # Check if the file is a valid audio format
        valid_formats = ['.mp3', '.mp4', '.mpeg', '.mpga', '.m4a', '.wav', '.webm']
        file_ext = os.path.splitext(audio_file.filename)[1].lower()
        
        if file_ext not in valid_formats:
            await interaction.response.send_message(
                f"Invalid file format. Please upload one of the following: {', '.join(valid_formats)}",
                ephemeral=True
            )
            return
        
        # Check file size (10MB max for Whisper API)
        if audio_file.size > 10 * 1024 * 1024:  # 10MB in bytes
            await interaction.response.send_message(
                "File too large. Please upload an audio file smaller than 10MB.",
                ephemeral=True
            )
            return
        
        await interaction.response.defer(ephemeral=ephemeral)
        
        try:
            logger.info(f"Transcribing audio file from {interaction.user}: {audio_file.filename}")
            
            # Download the audio file
            with tempfile.NamedTemporaryFile(suffix=file_ext, delete=False) as temp_file:
                temp_path = temp_file.name
                audio_bytes = await audio_file.read()
                temp_file.write(audio_bytes)
            
            # Transcribe the audio using OpenAI Whisper
            transcription = await transcribe_audio(temp_path)
            
            # Clean up the temporary file
            os.unlink(temp_path)
            
            # Send the transcription
            embed = create_response_embed(
                title="Audio Transcription",
                description=transcription,
                user=interaction.user,
                footer=f"File: {audio_file.filename}"
            )
            
            await interaction.followup.send(embed=embed, ephemeral=ephemeral)
            logger.info(f"Sent transcription to {interaction.user}")
        except Exception as e:
            logger.error(f"Error in /transcribe command: {e}")
            await interaction.followup.send(f"Error transcribing audio: {str(e)}", ephemeral=True)
    
    @app_commands.command(name="voice_response", description="Convert text to speech using OpenAI's TTS")
    @app_commands.describe(
        text="The text to convert to speech",
        voice="The voice to use",
        ephemeral="Whether the response should be visible only to you"
    )
    async def voice_response(
        self,
        interaction: discord.Interaction,
        text: str,
        voice: app_commands.Choice[str] = app_commands.Choice(name="Alloy (default)", value="alloy"),
        ephemeral: bool = False
    ):
        """Currently a placeholder for future TTS implementation.
        
        Note: TTS is not implemented yet due to the complexity of handling audio files in Discord.
        This command is a placeholder for future implementation.
        """
        await interaction.response.send_message(
            "Voice responses are not implemented yet. This feature will be available in a future update.",
            ephemeral=True
        )

async def setup(bot):
    """Setup function to add the cog to the bot."""
    await bot.add_cog(Voice(bot))
