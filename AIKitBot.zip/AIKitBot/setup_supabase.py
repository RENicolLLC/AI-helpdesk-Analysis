import os
import logging
import json
import time
import requests
from dotenv import load_dotenv
from supabase import create_client, Client

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Load environment variables
load_dotenv()

# Get Supabase credentials
SUPABASE_URL = os.environ.get("SUPABASE_URL")
SUPABASE_KEY = os.environ.get("SUPABASE_KEY")
SUPABASE_SERVICE_ROLE_KEY = os.environ.get("SUPABASE_SERVICE_ROLE_KEY")  # For admin operations

def run_sql_query(sql):
    """Run a SQL query using the service role key"""
    headers = {
        "apikey": SUPABASE_SERVICE_ROLE_KEY,
        "Authorization": f"Bearer {SUPABASE_SERVICE_ROLE_KEY}",
        "Content-Type": "application/json",
        "Prefer": "return=representation"
    }
    
    data = {"query": sql}
    
    response = requests.post(
        f"{SUPABASE_URL}/rest/v1/rpc/execute_sql",
        headers=headers,
        json=data
    )
    
    if response.status_code >= 200 and response.status_code < 300:
        logger.info("SQL query executed successfully")
        return True
    else:
        logger.error(f"Error executing SQL query: {response.status_code} - {response.text}")
        return False

def create_discord_users_table(supabase):
    """Create the discord_users table if it doesn't exist"""
    # First create RPC function for executing SQL (if it doesn't exist)
    rpc_function_sql = """
    CREATE OR REPLACE FUNCTION execute_sql(query text)
    RETURNS void
    LANGUAGE plpgsql
    SECURITY DEFINER
    AS $$
    BEGIN
        EXECUTE query;
    END;
    $$;
    """
    
    # Try to create the RPC function directly
    headers = {
        "apikey": SUPABASE_SERVICE_ROLE_KEY,
        "Authorization": f"Bearer {SUPABASE_SERVICE_ROLE_KEY}",
        "Content-Type": "application/json"
    }
    
    response = requests.post(
        f"{SUPABASE_URL}/rest/v1/sql",
        headers=headers,
        json={"query": rpc_function_sql}
    )
    
    if response.status_code >= 200 and response.status_code < 300:
        logger.info("RPC function created successfully")
    else:
        logger.warning(f"Could not create RPC function: {response.status_code} - {response.text}")
    
    # Create table using direct API call or our RPC function
    create_table_sql = """
    CREATE TABLE IF NOT EXISTS discord_users (
        id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        discord_id TEXT NOT NULL UNIQUE,
        username TEXT,
        premium BOOLEAN DEFAULT FALSE,
        premium_tier INTEGER DEFAULT 0,
        preferences JSONB DEFAULT '{"preferred_language": "en", "preferred_model": "gpt-3.5-turbo-0125"}',
        opt_in_features JSONB DEFAULT '{"notifications": false, "beta_features": false}',
        tebex_customer_id TEXT,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
    );
    """
    
    response = requests.post(
        f"{SUPABASE_URL}/rest/v1/sql",
        headers=headers,
        json={"query": create_table_sql}
    )
    
    if response.status_code >= 200 and response.status_code < 300:
        logger.info("discord_users table created successfully via direct SQL")
        return True
    else:
        logger.warning(f"Could not create table via direct SQL: {response.status_code} - {response.text}")
        # Try alternate method with our RPC function
        success = run_sql_query(create_table_sql)
        if success:
            logger.info("discord_users table created successfully via RPC")
            return True
        else:
            logger.error("Failed to create discord_users table")
            return False

def create_token_usage_table(supabase):
    """Create the token_usage table if it doesn't exist"""
    # Create table using direct API call
    create_table_sql = """
    CREATE TABLE IF NOT EXISTS token_usage (
        id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        discord_id TEXT NOT NULL,
        command TEXT,
        model TEXT,
        tokens INTEGER,
        estimated_cost FLOAT,
        timestamp TIMESTAMP WITH TIME ZONE DEFAULT now()
    );
    """
    
    headers = {
        "apikey": SUPABASE_SERVICE_ROLE_KEY,
        "Authorization": f"Bearer {SUPABASE_SERVICE_ROLE_KEY}",
        "Content-Type": "application/json"
    }
    
    response = requests.post(
        f"{SUPABASE_URL}/rest/v1/sql",
        headers=headers,
        json={"query": create_table_sql}
    )
    
    if response.status_code >= 200 and response.status_code < 300:
        logger.info("token_usage table created successfully via direct SQL")
        return True
    else:
        logger.warning(f"Could not create table via direct SQL: {response.status_code} - {response.text}")
        # Try alternate method with our RPC function
        success = run_sql_query(create_table_sql)
        if success:
            logger.info("token_usage table created successfully via RPC")
            return True
        else:
            logger.error("Failed to create token_usage table")
            return False

def test_user_insertion(supabase):
    """Test inserting a user into the discord_users table"""
    try:
        # Try to insert a test user
        test_user_data = {
            "discord_id": "123456789",
            "username": "TestUser",
            "premium": False,
            "premium_tier": 0,
            "preferences": json.dumps({
                "preferred_language": "en",
                "preferred_model": "gpt-3.5-turbo-0125"
            }),
            "opt_in_features": json.dumps({
                "notifications": False,
                "beta_features": False
            })
        }
        
        response = supabase.table("discord_users").insert(test_user_data).execute()
        
        if response.data and len(response.data) > 0:
            logger.info("Test user inserted successfully")
            return True
        else:
            logger.error("Failed to insert test user")
            return False
    except Exception as e:
        logger.error(f"Error inserting test user: {e}")
        return False

def main():
    logger.info(f"Initializing Supabase with URL: {SUPABASE_URL[:15]}... and KEY: {SUPABASE_KEY[:15]}...")
    
    if not SUPABASE_URL or not SUPABASE_KEY:
        logger.error("Supabase credentials not found in environment variables")
        return
    
    if not SUPABASE_SERVICE_ROLE_KEY:
        logger.warning("Supabase service role key not found - will not be able to create tables")
    
    try:
        # Initialize Supabase client
        supabase = create_client(SUPABASE_URL, SUPABASE_KEY)
        logger.info("Supabase client initialized successfully")
        
        # Check if discord_users table exists by attempting to select from it
        table_exists = False
        try:
            response = supabase.table("discord_users").select("*").limit(1).execute()
            logger.info(f"discord_users table exists with {len(response.data)} records")
            table_exists = True
        except Exception as e:
            logger.error(f"Error accessing discord_users table: {e}")
            
            if SUPABASE_SERVICE_ROLE_KEY:
                logger.info("Creating discord_users table...")
                success = create_discord_users_table(supabase)
                if success:
                    table_exists = True
                    time.sleep(1)  # Give Supabase time to process
            else:
                logger.info("Cannot create table: missing service role key")
                logger.info("SQL for creating discord_users table:\n")
                logger.info("""
                CREATE TABLE IF NOT EXISTS discord_users (
                    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
                    discord_id TEXT NOT NULL UNIQUE, 
                    username TEXT,
                    premium BOOLEAN DEFAULT FALSE,
                    premium_tier INTEGER DEFAULT 0,
                    preferences JSONB DEFAULT '{"preferred_language": "en", "preferred_model": "gpt-3.5-turbo-0125"}',
                    opt_in_features JSONB DEFAULT '{"notifications": false, "beta_features": false}',
                    tebex_customer_id TEXT,
                    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
                    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
                );
                """)
                logger.info("Please run this SQL in the Supabase SQL Editor")
        
        # Check if token_usage table exists
        try:
            response = supabase.table("token_usage").select("*").limit(1).execute()
            logger.info(f"token_usage table exists with {len(response.data)} records")
        except Exception as e:
            logger.error(f"Error accessing token_usage table: {e}")
            
            if SUPABASE_SERVICE_ROLE_KEY:
                logger.info("Creating token_usage table...")
                create_token_usage_table(supabase)
                time.sleep(1)  # Give Supabase time to process
            else:
                logger.info("Cannot create table: missing service role key")
                logger.info("SQL for creating token_usage table:\n")
                logger.info("""
                CREATE TABLE IF NOT EXISTS token_usage (
                    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
                    discord_id TEXT NOT NULL,
                    command TEXT,
                    model TEXT,
                    tokens INTEGER,
                    estimated_cost FLOAT,
                    timestamp TIMESTAMP WITH TIME ZONE DEFAULT now()
                );
                """)
                logger.info("Please run this SQL in the Supabase SQL Editor")
        
        # Test user insertion if tables exist
        if table_exists:
            logger.info("Testing user insertion...")
            test_user_insertion(supabase)
        
        logger.info("Supabase setup check complete")
        
    except Exception as e:
        logger.error(f"Error setting up Supabase: {e}")

if __name__ == "__main__":
    main()