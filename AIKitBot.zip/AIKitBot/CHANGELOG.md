# Changelog

All notable changes to the AIkitsBot project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2025-05-06

### Added
- Initial release with Discord bot integration
- AI chat functionality with OpenAI integration
- Intelligent model selection based on query complexity
  - gpt-3.5-turbo-0125 for routine tasks
  - GPT-4o for complex queries
- Slash commands:
  - `/ask` - General AI queries
  - `/custom` - Template-based AI responses
  - `/translate` - Language translation
  - `/web_search` - Web content extraction and analysis
  - `/transcribe` - Audio transcription with Whisper
  - `/settings` - User preference management
  - `/profile` - User statistics and profile
  - `/remindme` - Reminder system
- Auto-response in channel named "ai-chat"
- PostgreSQL database integration
  - Command usage tracking
  - Token usage monitoring
  - User profiles storage
  - Chat message history
  - Reminder system
- Supabase integration for premium features
- User preference system
- Web monitoring interface
- Comprehensive error handling

### Fixed
- Command duplication issues in main.py
- Properly organized code with cog system
- Structured database models with SQLAlchemy

### Changed
- Optimized AI model selection for cost efficiency
- Enhanced error handling for Discord interactions
